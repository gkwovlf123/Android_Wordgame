package com.example.myappproject;

public class userlist {
    String userspnum;
    String userspid;
    String userspnickname;
    String userspchnum;

    public String getUserspnum() {
        return userspnum;
    }

    public void setUserspnum(String userspnum) {
        this.userspnum = userspnum;
    }

    public String getUserspid() {
        return userspid;
    }

    public void setUserspid(String userspid) {
        this.userspid = userspid;
    }

    public String getUserspnickname() {
        return userspnickname;
    }

    public void setUserspnickname(String userspnickname) {
        this.userspnickname = userspnickname;
    }

    public String getUserspchnum() {
        return userspchnum;
    }

    public void setUserspchnum(String userspchnum) {
        this.userspchnum = userspchnum;
    }


}
