package com.example.myappproject;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.util.SparseBooleanArray;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;

public class worddelete extends AppCompatActivity {
    ListView listView;
    worddeleteadapter worddeleteadapter;
    Button btnworddelete, btnwordupdate;
    String name1, answer1, temp, name2, answer2;
    Handler handler2 = new Handler();
    EditText name, answer;
    boolean ischecked = false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_worddelete);
        name = findViewById(R.id.name);
        answer = findViewById(R.id.answer);
        btnwordupdate = findViewById(R.id.btnwordupdate);
        Spinner spinner = findViewById(R.id.spinner2);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,R.array.word_array, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(worddelete.this, parent.getItemAtPosition(position).toString(), Toast.LENGTH_SHORT).show();
                temp = parent.getItemAtPosition(position).toString();
                listselect(temp);
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        listView = findViewById(R.id.wordlist);
        worddeleteadapter = new worddeleteadapter();
        btnworddelete = findViewById(R.id.button6);
        btnworddelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(worddelete.this);
                builder.setTitle("정말 삭제하시겠습니까?");
                builder.setPositiveButton("아니오", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(worddelete.this, "취소되었습니다", Toast.LENGTH_SHORT).show();
                    }
                });
                builder.setNegativeButton("예", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        name1 = name.getText().toString();
                        answer1 = answer.getText().toString();
                        if(name1.isEmpty() && answer1.isEmpty()) {
                            AlertDialog.Builder builder = new AlertDialog.Builder(worddelete.this);
                            builder.setTitle("텍스트가 비어있습니다!");
                            builder.setNegativeButton("예", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {

                                }
                            });
                            builder.create();
                            builder.show();
                        }
                        else if(ischecked==false) {
                            AlertDialog.Builder builder = new AlertDialog.Builder(worddelete.this);
                            builder.setTitle("단어를 선택해주세요!");
                            builder.setNegativeButton("예", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                }
                            });
                            builder.create();
                            builder.show();
                        }
                        else {
                            listdelete(name1);
                            SparseBooleanArray checkedItems = listView.getCheckedItemPositions();
                            int count = worddeleteadapter.getCount();
                            for (int i = count - 1; i >= 0; i--) {
                                if (checkedItems.get(i)) {
                                    worddeleteadapter.remove(i);
                                }
                            }
                            // 모든 선택 상태 초기화.
                            worddeleteadapter.notifyDataSetChanged();
                        }
                    }
                });
                builder.create();
                builder.show();
            }
        });
        btnwordupdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(worddelete.this);
                builder.setTitle("정말 수정하시겠습니까?");
                builder.setPositiveButton("아니오", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(worddelete.this, "취소되었습니다", Toast.LENGTH_SHORT).show();
                    }
                });
                builder.setNegativeButton("예", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        name1 = name.getText().toString();
                        answer1 = answer.getText().toString();
                        if (name1.isEmpty() && answer1.isEmpty()) {
                            AlertDialog.Builder builder = new AlertDialog.Builder(worddelete.this);
                            builder.setTitle("텍스트가 비어있습니다!");
                            builder.setNegativeButton("예", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {

                                }
                            });
                            builder.create();
                            builder.show();
                        }
                        else if (ischecked == false) {
                            AlertDialog.Builder builder = new AlertDialog.Builder(worddelete.this);
                            builder.setTitle("리스트가 체크되어있지 않습니다!");
                            builder.setNegativeButton("예", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                }
                            });
                            builder.create();
                            builder.show();
                        }
                        else {
                            wordupdate(name1,answer1,name2,temp);
                            worddeleteadapter.notifyDataSetChanged();
                        }
                    }
                });
                builder.create();
                builder.show();
            }
        });
    }
    public void listselect(String themed) {
        new Thread() {
            @Override
            public void run() {
                try {
                    URL seturl = new URL("Http://10.0.2.2/listselect.php/");
                    HttpURLConnection http;
                    http = (HttpURLConnection) seturl.openConnection();
                    http.setDefaultUseCaches(false);
                    http.setDoInput(true);
                    http.setRequestMethod("POST");
                    http.setRequestProperty("content-type", "application/x-www-form-urlencoded");
                    StringBuffer buffer = new StringBuffer();
                    buffer.append("name").append("=").append(themed);
                    OutputStreamWriter out = new OutputStreamWriter(http.getOutputStream(), "UTF-8");
                    out.write(buffer.toString());
                    out.flush();

                    InputStreamReader tmp = new InputStreamReader(http.getInputStream(), "UTF-8");
                    BufferedReader reader = new BufferedReader(tmp);
                    StringBuilder builder = new StringBuilder();
                    String str;
                    while ((str = reader.readLine()) != null) {
                        builder.append(str);
                        builder.append("\n");
                    }
                    String ResultData = builder.toString();
                    final String[] Result = ResultData.split("#");
                    final int count = Result.length;
                    handler2.post(new Runnable() {
                        @Override
                        public void run() {
                            if(count==1) {
                                AlertDialog.Builder builder = new AlertDialog.Builder(worddelete.this);
                                builder.setTitle("리스트를 불러오지 못했습니다");
                                builder.setNegativeButton("예", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {

                                    }
                                });
                                builder.create();
                                builder.show();
                            }
                            else {
                                worddeleteadapter.itemclear();
                                for (int i = 1; i < count; i++) {
                                    final String[] Result2 = Result[i].split("/");
                                    worddeleteadapter.additem("번호"+Result2[0],Result2[1],Result2[2]);
                                }
                                listView.setAdapter(worddeleteadapter);
                                listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                                    @Override
                                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                                        worddeleteitem item = (worddeleteitem)parent.getItemAtPosition(position);
                                        name2 = item.getName().toString();
                                        answer2 = item.getAnswer();
                                        name.setText(item.getName());
                                        answer.setText(item.getAnswer());
                                        ischecked = true;
                                    }
                                });
                            }
                        }
                    });

                } catch (Exception e) {
                    Log.e("dataselect()", "지정에러발생", e);
                }
            }
        }.start();
    }
    public void listdelete(String named) {
        new Thread() {
            @Override
            public void run() {
                try {
                    URL seturl = new URL("Http://10.0.2.2/listdelete.php/");
                    HttpURLConnection http;
                    http = (HttpURLConnection) seturl.openConnection();
                    http.setDefaultUseCaches(false);
                    http.setDoInput(true);
                    http.setRequestMethod("POST");
                    http.setRequestProperty("content-type", "application/x-www-form-urlencoded");
                    StringBuffer buffer = new StringBuffer();
                    buffer.append("name").append("=").append(named);
                    OutputStreamWriter out = new OutputStreamWriter(http.getOutputStream(), "UTF-8");
                    out.write(buffer.toString());
                    out.flush();

                    InputStreamReader tmp = new InputStreamReader(http.getInputStream(), "UTF-8");
                    BufferedReader reader = new BufferedReader(tmp);
                    StringBuilder builder = new StringBuilder();
                    String ResultData = builder.toString();
                    final String[] Result = ResultData.split("/");
                    handler2.post(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(worddelete.this, "해당정보가 삭제되었습니다", Toast.LENGTH_SHORT).show();
                            name.setText("");
                            answer.setText("");
                        }
                    });

                } catch (Exception e) {
                    Log.e("dataInsert()", "지정에러발생", e);
                }
            }
        }.start();
    }
    public void wordupdate(String named, String answerd, String nameed, String theme) {
        new Thread() {
            @Override
            public void run() {
                try {
                    URL seturl = new URL("Http://10.0.2.2/listupdate.php/");
                    HttpURLConnection http;
                    http = (HttpURLConnection) seturl.openConnection();
                    http.setDefaultUseCaches(false);
                    http.setDoInput(true);
                    http.setRequestMethod("POST");
                    http.setRequestProperty("content-type", "application/x-www-form-urlencoded");
                    StringBuffer buffer = new StringBuffer();
                    buffer.append("name").append("=").append(named).append("/").append(answerd).append("/").append(nameed).append("/").append(theme);
                    OutputStreamWriter out = new OutputStreamWriter(http.getOutputStream(), "UTF-8");
                    out.write(buffer.toString());
                    out.flush();

                    InputStreamReader tmp = new InputStreamReader(http.getInputStream(), "UTF-8");
                    BufferedReader reader = new BufferedReader(tmp);
                    StringBuilder builder = new StringBuilder();
                    String str;
                    while ((str = reader.readLine()) != null) {
                        builder.append(str);
                    }
                    String ResultData = builder.toString();
                    final String[] Result = ResultData.split("/");
                    handler2.post(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(worddelete.this, "수정되었습니다", Toast.LENGTH_SHORT).show();
                            name.setText("");
                            answer.setText("");
                        }
                    });

                } catch (Exception e) {
                    Log.e("dataInsert()", "지정에러발생", e);
                }
            }
        }.start();
    }
}