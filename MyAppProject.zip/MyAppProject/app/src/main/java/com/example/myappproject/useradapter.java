package com.example.myappproject;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class useradapter extends BaseAdapter {
    ArrayList<userlist> List = new ArrayList<>();
    @Override
    public int getCount() {
        return List.size();
    }

    @Override
    public Object getItem(int position) {
        return List.get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        final int pos = position;
        final Context context = parent.getContext();
        if(convertView==null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(R.layout.useritemlayout,parent,false);
        }
        TextView txtspnum =  convertView.findViewById(R.id.userspnum);
        TextView txtspid =  convertView.findViewById(R.id.userspid);
        TextView txtspnickname =  convertView.findViewById(R.id.userspnickname);
        TextView txtspchnum =  convertView.findViewById(R.id.userspchnum);
        userlist userlist = List.get(position);
        txtspnum.setText(userlist.getUserspnum());
        txtspid.setText(userlist.getUserspid());
        txtspnickname.setText(userlist.getUserspnickname());
        txtspchnum.setText(userlist.getUserspchnum());
        return convertView;
    }
    public void additem(String num, String id, String nickname, String chnum) {
        userlist item = new userlist();
        item.setUserspnum(num);
        item.setUserspid(id);
        item.setUserspnickname(nickname);
        item.setUserspchnum(chnum);
        List.add(item);
    }
    public void itemclear() {
        List.clear();
    }
    public void remove(int position) {
        List.remove(position);
    }
}
