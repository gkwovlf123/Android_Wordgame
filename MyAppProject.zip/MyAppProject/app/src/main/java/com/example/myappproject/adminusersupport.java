package com.example.myappproject;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.util.SparseBooleanArray;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;

public class adminusersupport extends AppCompatActivity {
    Button btnuserchname, btndeluser;
    ListView listView;
    useradapter useradapter;
    String nickname2, changenum2, id2,i;
    int temp;
    Handler handler2 = new Handler();
    boolean ischecked = false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_adminusersupport);
        listView = findViewById(R.id.userlist);
        useradapter = new useradapter();
        listView.setAdapter(useradapter);
        listselect();
        btnuserchname = findViewById(R.id.btnuserchname);
        btnuserchname.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(adminusersupport.this);
                builder.setTitle("User1로 닉네임 변경 시키시겠습니까?");
                builder.setPositiveButton("아니오", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(adminusersupport.this, "취소했습니다", Toast.LENGTH_SHORT).show();
                    }
                });
                builder.setNegativeButton("예", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if(ischecked==false) {
                            AlertDialog.Builder builder1 = new AlertDialog.Builder(adminusersupport.this);
                            builder1.setTitle("유저를 선택해주세요!");
                            builder1.setNegativeButton("예", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {

                                }
                            });
                        }
                        else {
                            temp = Integer.parseInt(changenum2);
                            temp++;
                            i = Integer.toString(temp);
                            listupdate(i,id2);
                            Toast.makeText(adminusersupport.this, "변경되었습니다.", Toast.LENGTH_SHORT).show();
                            listselect();
                        }
                    }
                });
                builder.create();
                builder.show();
            }
        });
        btndeluser = findViewById(R.id.btndeluser);
        btndeluser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(adminusersupport.this);
                builder.setTitle("정말 삭제하시겠습니까?");
                builder.setPositiveButton("아니오", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(adminusersupport.this, "취소되었습니다", Toast.LENGTH_SHORT).show();
                    }
                });
                builder.setNegativeButton("예", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if(ischecked==false) {
                            AlertDialog.Builder builder1 = new AlertDialog.Builder(adminusersupport.this);
                            builder1.setTitle("유저를 선택해주세요!");
                            builder1.setNegativeButton("예", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {

                                }
                            });
                        }
                        else {
                            listdelete(id2);
                            SparseBooleanArray checkedItems = listView.getCheckedItemPositions();
                            int count = useradapter.getCount();
                            for (int i = count - 1; i >= 0; i--) {
                                if (checkedItems.get(i)) {
                                    useradapter.remove(i);
                                }
                            }
                            listView.clearChoices();
                            listselect();
                        }
                    }
                });
                builder.create();
                builder.show();
            }
        });
    }
    public void listselect() {
        new Thread() {
            @Override
            public void run() {
                try {
                    URL seturl = new URL("Http://10.0.2.2/userlistselect.php/");
                    HttpURLConnection http;
                    http = (HttpURLConnection) seturl.openConnection();
                    http.setDefaultUseCaches(false);
                    http.setDoInput(true);
                    http.setRequestMethod("POST");
                    http.setRequestProperty("content-type", "application/x-www-form-urlencoded");
                    StringBuffer buffer = new StringBuffer();
                    buffer.append("name").append("=");
                    OutputStreamWriter out = new OutputStreamWriter(http.getOutputStream(), "UTF-8");
                    out.write(buffer.toString());
                    out.flush();

                    InputStreamReader tmp = new InputStreamReader(http.getInputStream(), "UTF-8");
                    BufferedReader reader = new BufferedReader(tmp);
                    StringBuilder builder = new StringBuilder();
                    String str;
                    while ((str = reader.readLine()) != null) {
                        builder.append(str);
                        builder.append("\n");
                    }
                    String ResultData = builder.toString();
                    final String[] Result = ResultData.split("#");
                    final int count = Result.length;
                    handler2.post(new Runnable() {
                        @Override
                        public void run() {
                            if(count==1) {
                                AlertDialog.Builder builder = new AlertDialog.Builder(adminusersupport.this);
                                builder.setTitle("리스트를 불러오지 못했습니다");
                                builder.setNegativeButton("예", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {

                                    }
                                });
                                builder.create();
                                builder.show();
                            }
                            else {
                                useradapter.itemclear();
                                for (int i = 1; i < count; i++) {
                                    final String[] Result2 = Result[i].split("/");
                                    useradapter.additem(Result2[0],Result2[1],Result2[2],Result2[3]);
                                }
                                listView.setAdapter(useradapter);
                                listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                                    @Override
                                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                                        userlist item = (userlist) parent.getItemAtPosition(position);
                                        id2 = item.getUserspid();
                                        nickname2 = item.getUserspnickname();
                                        changenum2 = item.getUserspchnum().trim();
                                        Toast.makeText(adminusersupport.this, id2 + nickname2+changenum2, Toast.LENGTH_SHORT).show();
                                        ischecked = true;
                                    }
                                });
                            }
                        }
                    });

                } catch (Exception e) {
                    Log.e("dataselect()", "지정에러발생", e);
                }
            }
        }.start();
    }
    public void listdelete(String id2d) {
        new Thread() {
            @Override
            public void run() {
                try {
                    URL seturl = new URL("Http://10.0.2.2/userlistdelete.php/");
                    HttpURLConnection http;
                    http = (HttpURLConnection) seturl.openConnection();
                    http.setDefaultUseCaches(false);
                    http.setDoInput(true);
                    http.setRequestMethod("POST");
                    http.setRequestProperty("content-type", "application/x-www-form-urlencoded");
                    StringBuffer buffer = new StringBuffer();
                    buffer.append("name").append("=").append(id2d);
                    OutputStreamWriter out = new OutputStreamWriter(http.getOutputStream(), "UTF-8");
                    out.write(buffer.toString());
                    out.flush();

                    InputStreamReader tmp = new InputStreamReader(http.getInputStream(), "UTF-8");
                    BufferedReader reader = new BufferedReader(tmp);
                    StringBuilder builder = new StringBuilder();
                    String ResultData = builder.toString();
                    final String[] Result = ResultData.split("/");
                    handler2.post(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(adminusersupport.this, "해당정보가 삭제되었습니다", Toast.LENGTH_SHORT).show();
                        }
                    });

                } catch (Exception e) {
                    Log.e("dataInsert()", "지정에러발생", e);
                }
            }
        }.start();
    }
    public void listupdate(String changenumd, String idd) {
        new Thread() {
            @Override
            public void run() {
                try {
                    URL seturl = new URL("Http://10.0.2.2/userlistupdate.php/");
                    HttpURLConnection http;
                    http = (HttpURLConnection) seturl.openConnection();
                    http.setDefaultUseCaches(false);
                    http.setDoInput(true);
                    http.setRequestMethod("POST");
                    http.setRequestProperty("content-type", "application/x-www-form-urlencoded");
                    StringBuffer buffer = new StringBuffer();
                    buffer.append("name").append("=").append(changenumd).append("/").append(idd);
                    OutputStreamWriter out = new OutputStreamWriter(http.getOutputStream(), "UTF-8");
                    out.write(buffer.toString());
                    out.flush();

                    InputStreamReader tmp = new InputStreamReader(http.getInputStream(), "UTF-8");
                    BufferedReader reader = new BufferedReader(tmp);
                    StringBuilder builder = new StringBuilder();
                    String str;
                    while ((str = reader.readLine()) != null) {
                        builder.append(str);
                    }
                    String ResultData = builder.toString();
                    final String[] Result = ResultData.split("/");
                    handler2.post(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(adminusersupport.this, "수정되었습니다", Toast.LENGTH_SHORT).show();

                        }
                    });

                } catch (Exception e) {
                    Log.e("dataInsert()", "지정에러발생", e);
                }
            }
        }.start();
    }
}