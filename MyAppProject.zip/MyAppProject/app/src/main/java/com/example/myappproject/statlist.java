package com.example.myappproject;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.Checkable;
import android.widget.LinearLayout;
import android.widget.RadioButton;

import androidx.annotation.Nullable;

public class statlist {
    String date;
    String theme;
    String answer;
    String wronganswer;


    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTheme() {
        return theme;
    }

    public void setTheme(String theme) {
        this.theme = theme;
    }

    public String getAnswer() {
        return answer;
    }

    public void setAnswer(String answer) {
        this.answer = answer;
    }

    public String getWronganswer() {
        return wronganswer;
    }

    public void setWronganswer(String wronganswer) {
        this.wronganswer = wronganswer;
    }

}
