package com.example.myappproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TableLayout;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;

public class wordtheme extends AppCompatActivity {
    TableLayout tableLayout;
    TextView wordtitle, txtanimal, txt1,txt2,txt3;
    Button btnanimal;
    Handler handler2 = new Handler();
    String id;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wordtheme);
        btnanimal = findViewById(R.id.btnanimal);
        tableLayout = findViewById(R.id.wordthemetable);
        wordtitle = findViewById(R.id.wordthemetitle);
        txtanimal = findViewById(R.id.txtanimal);
        txt1 = findViewById(R.id.textView9);
        txt2 = findViewById(R.id.textView17);
        txt3 = findViewById(R.id.textView20);
        Intent intent = getIntent();
        id = intent.getStringExtra("userid");
        // 배경색, 텍스트 색 관련
        animalselect();
        if(AppOption.color==1) {
            tableLayout.setBackgroundColor(Color.parseColor("#ffff4444"));
            wordtitle.setTextColor(Color.WHITE);
            txtanimal.setTextColor(Color.WHITE);
            txt1.setTextColor(Color.WHITE);
            txt2.setTextColor(Color.WHITE);
            txt3.setTextColor(Color.WHITE);
        }
        else if(AppOption.color==2) {
            tableLayout.setBackgroundColor(Color.parseColor("#ffcc0000"));
            wordtitle.setTextColor(Color.WHITE);
            txtanimal.setTextColor(Color.WHITE);
            txt1.setTextColor(Color.WHITE);
            txt2.setTextColor(Color.WHITE);
            txt3.setTextColor(Color.WHITE);
        }
        else if(AppOption.color==3) {
            tableLayout.setBackgroundColor(Color.parseColor("#ffffbb33"));
            wordtitle.setTextColor(Color.WHITE);
            txtanimal.setTextColor(Color.WHITE);
            txt1.setTextColor(Color.WHITE);
            txt2.setTextColor(Color.WHITE);
            txt3.setTextColor(Color.WHITE);
        }
        else if(AppOption.color==4) {
            tableLayout.setBackgroundColor(Color.parseColor("#ff99cc00"));
            wordtitle.setTextColor(Color.WHITE);
            txtanimal.setTextColor(Color.WHITE);
            txt1.setTextColor(Color.WHITE);
            txt2.setTextColor(Color.WHITE);
            txt3.setTextColor(Color.WHITE);
        }
        else if(AppOption.color==5) {
            tableLayout.setBackgroundColor(Color.parseColor("#3700b3"));
            wordtitle.setTextColor(Color.WHITE);
            txtanimal.setTextColor(Color.WHITE);
            txt1.setTextColor(Color.WHITE);
            txt2.setTextColor(Color.WHITE);
            txt3.setTextColor(Color.WHITE);
        }
        else if(AppOption.color==6) {
            tableLayout.setBackgroundColor(Color.parseColor("#ff03dac5"));
            wordtitle.setTextColor(Color.WHITE);
            txtanimal.setTextColor(Color.WHITE);
            txt1.setTextColor(Color.WHITE);
            txt2.setTextColor(Color.WHITE);
            txt3.setTextColor(Color.WHITE);
        }
        else if(AppOption.color==7) {
            tableLayout.setBackgroundColor(Color.parseColor("#ff424242"));
            wordtitle.setTextColor(Color.WHITE);
            txtanimal.setTextColor(Color.WHITE);
            txt1.setTextColor(Color.WHITE);
            txt2.setTextColor(Color.WHITE);
            txt3.setTextColor(Color.WHITE);
        }
        else if(AppOption.color==8) {
            tableLayout.setBackgroundColor(Color.parseColor("#ffffffff"));
            wordtitle.setTextColor(Color.GRAY);
            txtanimal.setTextColor(Color.GRAY);
            txt1.setTextColor(Color.GRAY);
            txt2.setTextColor(Color.GRAY);
            txt3.setTextColor(Color.GRAY);
        }
        btnanimal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),gamescreen.class);
                intent.putExtra("userid",id);
                startActivity(intent);
            }
        });

    }
    public void animalselect() {
        new Thread() {
            @Override
            public void run() {
                try {
                    URL seturl = new URL("Http://10.0.2.2/countanimal.php/");
                    HttpURLConnection http;
                    http = (HttpURLConnection) seturl.openConnection();
                    http.setDefaultUseCaches(false);
                    http.setDoInput(true);
                    http.setRequestMethod("POST");
                    http.setRequestProperty("content-type", "application/x-www-form-urlencoded");
                    StringBuffer buffer = new StringBuffer();
                    buffer.append("name");
                    OutputStreamWriter out = new OutputStreamWriter(http.getOutputStream(), "UTF-8");
                    out.write(buffer.toString());
                    out.flush();

                    InputStreamReader tmp = new InputStreamReader(http.getInputStream(), "UTF-8");
                    BufferedReader reader = new BufferedReader(tmp);
                    StringBuilder builder = new StringBuilder();
                    String str;
                    while ((str = reader.readLine()) != null) {
                        builder.append(str);
                    }
                    String ResultData = builder.toString();
                    final String[] Result = ResultData.split("/");
                    handler2.post(new Runnable() {
                        @Override
                        public void run() {
                            txtanimal.setText(ResultData+"개");
                        }
                    });

                } catch (Exception e) {
                    Log.e("dataselect()", "지정에러발생", e);
                }
            }
        }.start();
    }
}