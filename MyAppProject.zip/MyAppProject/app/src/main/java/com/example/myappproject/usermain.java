package com.example.myappproject;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.navigation.NavigationView;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;

public class usermain extends AppCompatActivity {
    static DrawerLayout DrawerLayout;
    private Context context = this;
    boolean isDrawerOpened;
    Button btngamestart;
    TableLayout usermaintable;
    TextView tooltitle, navinickname, naviusercode;
    NavigationView view;
    View header, view_toolbar;
    LinearLayout navigatorheader;
    static String id;
    Handler handler2 = new Handler();
    int i;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_usermain);
        usermaintable = findViewById(R.id.usermaintablelayout);
        view_toolbar = findViewById(R.id.view_toolbar);
        tooltitle = findViewById(R.id.toolbar_title);
        view = findViewById(R.id.nav_view);
        header = view.getHeaderView(0);
        navigatorheader = header.findViewById(R.id.navigatorheader);
        navinickname = header.findViewById(R.id.naviusernickname);
        naviusercode = header.findViewById(R.id.naviusercode);
        Intent intent = getIntent();
        id = intent.getStringExtra("userid");
        getnickusercode(id);
        if(AppOption.color==1) {
            view_toolbar.setBackgroundColor(Color.parseColor("#ffff4444"));
            navigatorheader.setBackgroundColor(Color.parseColor("#ffff4444"));
        }
        else if(AppOption.color==2) {
            view_toolbar.setBackgroundColor(Color.parseColor("#ffcc0000"));
            navigatorheader.setBackgroundColor(Color.parseColor("#ffcc0000"));
        }
        else if(AppOption.color==3) {
            view_toolbar.setBackgroundColor(Color.parseColor("#ffffbb33"));
            navigatorheader.setBackgroundColor(Color.parseColor("#ffffbb33"));
        }
        else if(AppOption.color==4) {
            view_toolbar.setBackgroundColor(Color.parseColor("#ff99cc00"));
            navigatorheader.setBackgroundColor(Color.parseColor("#ff99cc00"));
        }
        else if(AppOption.color==5) {
            view_toolbar.setBackgroundColor(Color.parseColor("#3700b3"));
            navigatorheader.setBackgroundColor(Color.parseColor("#3700b3"));
        }
        else if(AppOption.color==6) {
            view_toolbar.setBackgroundColor(Color.parseColor("#ff03dac5"));
            navigatorheader.setBackgroundColor(Color.parseColor("#ff03dac5"));
        }
        else if(AppOption.color==7) {
            view_toolbar.setBackgroundColor(Color.parseColor("#ff424242"));
            navigatorheader.setBackgroundColor(Color.parseColor("#ff424242"));
        }
        else if(AppOption.color==8) {
            view_toolbar.setBackgroundColor(Color.parseColor("#ff000000"));
            navigatorheader.setBackgroundColor(Color.parseColor("#6200ee"));
        }
        Toolbar toolbar = (Toolbar)findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayShowTitleEnabled(false);
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setHomeAsUpIndicator(R.drawable.menu149719);
        btngamestart = findViewById(R.id.btngamestart);
        DrawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this,DrawerLayout,toolbar,R.string.navigation_drawer_open,R.string.navigation_drawer_close) {
            @Override
            public void onDrawerOpened(View drawerView) {
                super.onDrawerOpened(drawerView);
                isDrawerOpened = true;
            }
            @Override
            public void onDrawerClosed(View drawerView) {
                super.onDrawerClosed(drawerView);
                isDrawerOpened = false;
            }
        };
        DrawerLayout.addDrawerListener(toggle);
        toggle.syncState();
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(MenuItem item) {
                item.setChecked(true);
                int id = item.getItemId();
                String title = item.getTitle().toString();

                if(id==R.id.user_stat) {
                    Intent intent = new Intent(getApplicationContext(),uesrstat.class);
                    intent.putExtra("userid",usermain.id);
                    startActivity(intent);
                    Toast.makeText(context, title, Toast.LENGTH_SHORT).show();

                }
                else if(id==R.id.user_account) {
                    Intent intent = new Intent(getApplicationContext(),userdataupdate.class);
                    startActivity(intent);
                    Toast.makeText(context, title, Toast.LENGTH_SHORT).show();

                }
                else if(id==R.id.user_option) {
                    AppOption.isadmin=false;
                    Intent intent = new Intent(getApplicationContext(),AppOption.class);
                    intent.putExtra("userid",usermain.id);
                    startActivity(intent);
                    Toast.makeText(context, title, Toast.LENGTH_SHORT).show();

                }
                else if(id==R.id.user_logout) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(usermain.this);
                    builder.setMessage("로그아웃 하시겠습니까?");
                    builder.setPositiveButton("아니오", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            Toast.makeText(context, "취소되었습니다", Toast.LENGTH_SHORT).show();
                        }
                    });
                    builder.setNegativeButton("예", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                            Toast.makeText(context, "로그아웃 되었습니다.", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(getApplicationContext(),MainActivity.class);
                            startActivity(intent);
                        }
                    });
                    builder.create();
                    builder.show();
                }
                else if(id==R.id.user_delete){
                    AlertDialog.Builder builder = new AlertDialog.Builder(usermain.this);
                    builder.setMessage("회원탈퇴 하시겠습니까?");
                    builder.setPositiveButton("아니오", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            Toast.makeText(context, "취소되었습니다", Toast.LENGTH_SHORT).show();
                        }
                    });
                    builder.setNegativeButton("예", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            userdelete(usermain.id);
                        }
                    });
                    builder.create();
                    builder.show();
                }
                DrawerLayout.closeDrawers();
                return true;
            }
        });
        btngamestart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent gamestart = new Intent(getApplicationContext(),wordtheme.class);
                gamestart.putExtra("userid",id);
                startActivity(gamestart);

            }
        });

    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:{
                DrawerLayout.openDrawer(GravityCompat.START);
                return true;
            }
        }
        return super.onOptionsItemSelected(item);
    }
    @Override
    public void onBackPressed() {
        if(isDrawerOpened) {
            DrawerLayout.closeDrawer(Gravity.LEFT);
        }
        else {
            finish();
        }
    }
    public void getnickusercode(String idd) {
        new Thread() {
            @Override
            public void run() {
                try {
                    URL seturl = new URL("Http://10.0.2.2/getnicknameusercode.php/");
                    HttpURLConnection http;
                    http = (HttpURLConnection) seturl.openConnection();
                    http.setDefaultUseCaches(false);
                    http.setDoInput(true);
                    http.setRequestMethod("POST");
                    http.setRequestProperty("content-type", "application/x-www-form-urlencoded");
                    StringBuffer buffer = new StringBuffer();
                    buffer.append("name").append("=").append(idd);
                    OutputStreamWriter out = new OutputStreamWriter(http.getOutputStream(), "UTF-8");
                    out.write(buffer.toString());
                    out.flush();

                    InputStreamReader tmp = new InputStreamReader(http.getInputStream(), "UTF-8");
                    BufferedReader reader = new BufferedReader(tmp);
                    StringBuilder builder = new StringBuilder();
                    String str;
                    while ((str = reader.readLine()) != null) {
                        builder.append(str);
                    }
                    String ResultData = builder.toString();
                    final String[] Result = ResultData.split("/");
                    handler2.post(new Runnable() {
                        @Override
                        public void run() {
                            navinickname.setText("닉네임 : "+Result[0]);
                            naviusercode.setText("유저코드 : "+Result[1]);
                        }
                    });
                } catch (Exception e) {
                    Log.e("dataselect()", "지정에러발생", e);
                }
            }
        }.start();
    }
    public void userdelete(String idd) {
        new Thread() {
            @Override
            public void run() {
                try {
                    URL seturl = new URL("Http://10.0.2.2/userdelete.php/");
                    HttpURLConnection http;
                    http = (HttpURLConnection) seturl.openConnection();
                    http.setDefaultUseCaches(false);
                    http.setDoInput(true);
                    http.setRequestMethod("POST");
                    http.setRequestProperty("content-type", "application/x-www-form-urlencoded");
                    StringBuffer buffer = new StringBuffer();
                    buffer.append("name").append("=").append(idd);
                    OutputStreamWriter out = new OutputStreamWriter(http.getOutputStream(), "UTF-8");
                    out.write(buffer.toString());
                    out.flush();

                    InputStreamReader tmp = new InputStreamReader(http.getInputStream(), "UTF-8");
                    BufferedReader reader = new BufferedReader(tmp);
                    StringBuilder builder = new StringBuilder();
                    String ResultData = builder.toString();
                    final String[] Result = ResultData.split("/");
                    handler2.post(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(usermain.this, "회원탈퇴 되었습니다", Toast.LENGTH_SHORT).show();
                            System.exit(0);
                        }
                    });

                } catch (Exception e) {
                    Log.e("dataInsert()", "지정에러발생", e);
                }
            }
        }.start();
    }
}