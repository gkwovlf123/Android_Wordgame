package com.example.myappproject;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;

public class userdataupdate extends AppCompatActivity {
    EditText inputid, idagain, inputid1, pwagain, inputid2, nicknameagain,inputtel;
    Button btnupdateid, btnupdatepw, btnupdatenickname, btnupdatetel;
    TextView txt1,txt2,txt3,txt4,txt5,txt6,txt7,txt8,txt9,txt10,txt11,txt12;
    String id,ida,id1,pwa,id2,namea,tel,id3;
    Handler handler2 = new Handler();
    TableLayout table1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_userdataupdate);
        inputtel = findViewById(R.id.edid3);
        inputid = findViewById(R.id.edid);
        idagain = findViewById(R.id.edinputid);
        inputid1 = findViewById(R.id.edid1);
        pwagain = findViewById(R.id.edinputpw);
        inputid2 = findViewById(R.id.edid2);
        nicknameagain = findViewById(R.id.edinputnickname);
        table1 = findViewById(R.id.table1);
        btnupdateid = findViewById(R.id.btnidupdate);
        btnupdatepw = findViewById(R.id.btnupdatepw);
        btnupdatenickname = findViewById(R.id.btnupdatenickname);
        btnupdatetel = findViewById(R.id.btnupdatephone);
        txt1 = findViewById(R.id.txtupdatetitle);
        txt2 = findViewById(R.id.txtupdateidtitle);
        txt3 = findViewById(R.id.txtupdateid);
        txt4 = findViewById(R.id.txtupdateidagain);
        txt5 = findViewById(R.id.txtupdatepwtitle);
        txt6 = findViewById(R.id.txtupdatepw);
        txt7 = findViewById(R.id.txtupdatepwagain);
        txt8 = findViewById(R.id.txtupdatenicknametitle);
        txt9 = findViewById(R.id.txtupdatenickname);
        txt10 = findViewById(R.id.txtupdatenicknameagain);
        txt11 = findViewById(R.id.txtupdatephone);
        txt12 = findViewById(R.id.txtupdatephonetitle);

        if(AppOption.color==1) {
            table1.setBackgroundColor(Color.parseColor("#ffff4444"));
            txt1.setTextColor(Color.WHITE);
            txt2.setTextColor(Color.WHITE);
            txt3.setTextColor(Color.WHITE);
            txt4.setTextColor(Color.WHITE);
            txt5.setTextColor(Color.WHITE);
            txt6.setTextColor(Color.WHITE);
            txt7.setTextColor(Color.WHITE);
            txt8.setTextColor(Color.WHITE);
            txt9.setTextColor(Color.WHITE);
            txt10.setTextColor(Color.WHITE);
            txt11.setTextColor(Color.WHITE);
            txt12.setTextColor(Color.WHITE);
            inputid.setTextColor(Color.WHITE);
            idagain.setTextColor(Color.WHITE);
            inputid1.setTextColor(Color.WHITE);
            pwagain.setTextColor(Color.WHITE);
            inputid2.setTextColor(Color.WHITE);
            nicknameagain.setTextColor(Color.WHITE);
            inputtel.setTextColor(Color.WHITE);
        }
        else if(AppOption.color==2) {
            table1.setBackgroundColor(Color.parseColor("#ffcc0000"));
            txt1.setTextColor(Color.WHITE);
            txt2.setTextColor(Color.WHITE);
            txt3.setTextColor(Color.WHITE);
            txt4.setTextColor(Color.WHITE);
            txt5.setTextColor(Color.WHITE);
            txt6.setTextColor(Color.WHITE);
            txt7.setTextColor(Color.WHITE);
            txt8.setTextColor(Color.WHITE);
            txt9.setTextColor(Color.WHITE);
            txt10.setTextColor(Color.WHITE);
            inputid.setTextColor(Color.WHITE);
            idagain.setTextColor(Color.WHITE);
            inputid1.setTextColor(Color.WHITE);
            pwagain.setTextColor(Color.WHITE);
            inputid2.setTextColor(Color.WHITE);
            nicknameagain.setTextColor(Color.WHITE);
            txt11.setTextColor(Color.WHITE);
            txt12.setTextColor(Color.WHITE);
            inputtel.setTextColor(Color.WHITE);
        }
        else if(AppOption.color==3) {
            table1.setBackgroundColor(Color.parseColor("#ffffbb33"));
            txt1.setTextColor(Color.WHITE);
            txt2.setTextColor(Color.WHITE);
            txt3.setTextColor(Color.WHITE);
            txt4.setTextColor(Color.WHITE);
            txt5.setTextColor(Color.WHITE);
            txt6.setTextColor(Color.WHITE);
            txt7.setTextColor(Color.WHITE);
            txt8.setTextColor(Color.WHITE);
            txt9.setTextColor(Color.WHITE);
            txt10.setTextColor(Color.WHITE);
            inputid.setTextColor(Color.WHITE);
            idagain.setTextColor(Color.WHITE);
            inputid1.setTextColor(Color.WHITE);
            pwagain.setTextColor(Color.WHITE);
            inputid2.setTextColor(Color.WHITE);
            nicknameagain.setTextColor(Color.WHITE);
            txt11.setTextColor(Color.WHITE);
            txt12.setTextColor(Color.WHITE);
            inputtel.setTextColor(Color.WHITE);
        }
        else if(AppOption.color==4) {
            table1.setBackgroundColor(Color.parseColor("#ff99cc00"));
            txt1.setTextColor(Color.WHITE);
            txt2.setTextColor(Color.WHITE);
            txt3.setTextColor(Color.WHITE);
            txt4.setTextColor(Color.WHITE);
            txt5.setTextColor(Color.WHITE);
            txt6.setTextColor(Color.WHITE);
            txt7.setTextColor(Color.WHITE);
            txt8.setTextColor(Color.WHITE);
            txt9.setTextColor(Color.WHITE);
            txt10.setTextColor(Color.WHITE);
            inputid.setTextColor(Color.WHITE);
            idagain.setTextColor(Color.WHITE);
            inputid1.setTextColor(Color.WHITE);
            pwagain.setTextColor(Color.WHITE);
            inputid2.setTextColor(Color.WHITE);
            nicknameagain.setTextColor(Color.WHITE);
            txt11.setTextColor(Color.WHITE);
            txt12.setTextColor(Color.WHITE);
            inputtel.setTextColor(Color.WHITE);
        }
        else if(AppOption.color==5) {
            table1.setBackgroundColor(Color.parseColor("#3700b3"));
            txt1.setTextColor(Color.WHITE);
            txt2.setTextColor(Color.WHITE);
            txt3.setTextColor(Color.WHITE);
            txt4.setTextColor(Color.WHITE);
            txt5.setTextColor(Color.WHITE);
            txt6.setTextColor(Color.WHITE);
            txt7.setTextColor(Color.WHITE);
            txt8.setTextColor(Color.WHITE);
            txt9.setTextColor(Color.WHITE);
            txt10.setTextColor(Color.WHITE);
            inputid.setTextColor(Color.WHITE);
            idagain.setTextColor(Color.WHITE);
            inputid1.setTextColor(Color.WHITE);
            pwagain.setTextColor(Color.WHITE);
            inputid2.setTextColor(Color.WHITE);
            nicknameagain.setTextColor(Color.WHITE);
            txt11.setTextColor(Color.WHITE);
            txt12.setTextColor(Color.WHITE);
            inputtel.setTextColor(Color.WHITE);
        }
        else if(AppOption.color==6) {
            table1.setBackgroundColor(Color.parseColor("#ff03dac5"));
            txt1.setTextColor(Color.WHITE);
            txt2.setTextColor(Color.WHITE);
            txt3.setTextColor(Color.WHITE);
            txt4.setTextColor(Color.WHITE);
            txt5.setTextColor(Color.WHITE);
            txt6.setTextColor(Color.WHITE);
            txt7.setTextColor(Color.WHITE);
            txt8.setTextColor(Color.WHITE);
            txt9.setTextColor(Color.WHITE);
            txt10.setTextColor(Color.WHITE);
            inputid.setTextColor(Color.WHITE);
            idagain.setTextColor(Color.WHITE);
            inputid1.setTextColor(Color.WHITE);
            pwagain.setTextColor(Color.WHITE);
            inputid2.setTextColor(Color.WHITE);
            nicknameagain.setTextColor(Color.WHITE);
            txt11.setTextColor(Color.WHITE);
            txt12.setTextColor(Color.WHITE);
            inputtel.setTextColor(Color.WHITE);
        }
        else if(AppOption.color==7) {
            table1.setBackgroundColor(Color.parseColor("#ff424242"));
            txt1.setTextColor(Color.WHITE);
            txt2.setTextColor(Color.WHITE);
            txt3.setTextColor(Color.WHITE);
            txt4.setTextColor(Color.WHITE);
            txt5.setTextColor(Color.WHITE);
            txt6.setTextColor(Color.WHITE);
            txt7.setTextColor(Color.WHITE);
            txt8.setTextColor(Color.WHITE);
            txt9.setTextColor(Color.WHITE);
            txt10.setTextColor(Color.WHITE);
            inputid.setTextColor(Color.WHITE);
            idagain.setTextColor(Color.WHITE);
            inputid1.setTextColor(Color.WHITE);
            pwagain.setTextColor(Color.WHITE);
            inputid2.setTextColor(Color.WHITE);
            nicknameagain.setTextColor(Color.WHITE);
            txt11.setTextColor(Color.WHITE);
            txt12.setTextColor(Color.WHITE);
            inputtel.setTextColor(Color.WHITE);
        }
        else if(AppOption.color==8) {
            table1.setBackgroundColor(Color.parseColor("#ffffffff"));
            txt1.setTextColor(Color.GRAY);
            txt2.setTextColor(Color.GRAY);
            txt3.setTextColor(Color.GRAY);
            txt4.setTextColor(Color.GRAY);
            txt5.setTextColor(Color.GRAY);
            txt6.setTextColor(Color.GRAY);
            txt7.setTextColor(Color.GRAY);
            txt8.setTextColor(Color.GRAY);
            txt9.setTextColor(Color.GRAY);
            txt10.setTextColor(Color.GRAY);
            inputid.setTextColor(Color.GRAY);
            idagain.setTextColor(Color.GRAY);
            inputid1.setTextColor(Color.GRAY);
            pwagain.setTextColor(Color.GRAY);
            inputid2.setTextColor(Color.GRAY);
            nicknameagain.setTextColor(Color.GRAY);
            txt11.setTextColor(Color.GRAY);
            txt12.setTextColor(Color.GRAY);
            inputtel.setTextColor(Color.GRAY);
        }
        btnupdateid.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                id = inputid.getText().toString();
                ida = idagain.getText().toString();
                if(id.isEmpty() || ida.isEmpty()) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(userdataupdate.this);
                    builder.setTitle("모두 입력해주십시오!");
                    builder.setNegativeButton("예", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            inputid.setText("");
                            idagain.setText("");
                            idagain.setFocusable(true);
                            inputid.setFocusable(true);
                        }
                    });
                    builder.create();
                    builder.show();
                }
                else if(!id.equals(usermain.id)) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(userdataupdate.this);
                    builder.setTitle("현재 접속중인 ID와 일치하지않습니다!");
                    builder.setNegativeButton("예", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            inputid.setText("");
                            inputid.setFocusable(true);
                        }
                    });
                    builder.create();
                    builder.show();
                }
                else if(ida.matches("[ ]*")) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(userdataupdate.this);
                    builder.setTitle("ID에는 공백이 들어갈 수 없습니다!");
                    builder.setNegativeButton("예", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            idagain.setText("");
                            idagain.setFocusable(true);
                        }
                    });
                    builder.create();
                    builder.show();
                }
                else if(ida.length()<10 || ida.length()>15) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(userdataupdate.this);
                    builder.setTitle("ID에는 10자리 이상 15자리 이하만 입력할 수 있습니다!");
                    builder.setNegativeButton("예", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            idagain.setText("");
                            idagain.setFocusable(true);
                        }
                    });
                    builder.create();
                    builder.show();
                }
                else if(!ida.matches("[0-9|a-z|A-Z| ]*")) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(userdataupdate.this);
                    builder.setTitle("ID에는 특수문자 또는 한글은 입력할 수 없습니다!");
                    builder.setNegativeButton("예", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            idagain.setText("");
                            idagain.setFocusable(true);
                        }
                    });
                    builder.create();
                    builder.show();
                }
                else {
                    idcheck(ida);
                }
            }
        });
        btnupdatepw.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                id1 = inputid1.getText().toString();
                pwa = pwagain.getText().toString();
                if(id1.isEmpty() || pwa.isEmpty()) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(userdataupdate.this);
                    builder.setTitle("모두 입력해주십시오!");
                    builder.setNegativeButton("예", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            inputid1.setText("");
                            pwagain.setText("");
                            pwagain.setFocusable(true);
                            inputid1.setFocusable(true);
                        }
                    });
                    builder.create();
                    builder.show();
                }
                else if(!id1.equals(usermain.id)) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(userdataupdate.this);
                    builder.setTitle("현재 접속중인 ID와 일치하지않습니다!");
                    builder.setNegativeButton("예", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            inputid1.setText("");
                            inputid1.setFocusable(true);
                        }
                    });
                    builder.create();
                    builder.show();
                }
                else if(pwa.matches("[ ]*")) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(userdataupdate.this);
                    builder.setTitle("PW에는 공백이 들어갈 수 없습니다!");
                    builder.setNegativeButton("예", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            pwagain.setText("");
                            pwagain.setFocusable(true);
                        }
                    });
                    builder.create();
                    builder.show();
                }
                else if(pwa.length()<8 || pwa.length()>20) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(userdataupdate.this);
                    builder.setTitle("PW는 8자리 이상 20자리 이하만 입력할 수 있습니다!");
                    builder.setNegativeButton("예", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            pwagain.setText("");
                            pwagain.setFocusable(true);
                        }
                    });
                    builder.create();
                    builder.show();
                }
                else if(pwa.matches("[ㄱ-ㅎ|ㅏ-ㅣ|가-힝| ]*")) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(userdataupdate.this);
                    builder.setTitle("PW에 한글 및 공백은 입력할 수 없습니다!");
                    builder.setNegativeButton("예", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            pwagain.setText("");
                            pwagain.setFocusable(true);
                        }
                    });
                    builder.create();
                    builder.show();
                }
                else {
                    pwupdate(id1,pwa);
                }
            }
        });
        btnupdatenickname.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                id2 = inputid2.getText().toString();
                namea = nicknameagain.getText().toString();
                if(id2.isEmpty() || namea.isEmpty()) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(userdataupdate.this);
                    builder.setTitle("모두 입력해주십시오!");
                    builder.setNegativeButton("예", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            inputid2.setText("");
                            nicknameagain.setText("");
                            nicknameagain.setFocusable(true);
                            inputid2.setFocusable(true);
                        }
                    });
                    builder.create();
                    builder.show();
                }
                else if(!id2.equals(usermain.id)) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(userdataupdate.this);
                    builder.setTitle("현재 접속중인 ID와 일치하지않습니다!");
                    builder.setNegativeButton("예", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            inputid2.setText("");
                            inputid2.setFocusable(true);
                        }
                    });
                    builder.create();
                    builder.show();
                }
                else if(namea.matches("[ ]*")) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(userdataupdate.this);
                    builder.setTitle("닉네임에는 공백이 들어갈 수 없습니다!");
                    builder.setNegativeButton("예", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            nicknameagain.setText("");
                            nicknameagain.setFocusable(true);
                        }
                    });
                    builder.create();
                    builder.show();
                }
                else if(namea.length()>10) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(userdataupdate.this);
                    builder.setTitle("닉네임은 10글자를 넘을수 없습니다!");
                    builder.setNegativeButton("예", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            nicknameagain.setText("");
                            nicknameagain.setFocusable(true);
                        }
                    });
                    builder.create();
                    builder.show();
                }
                else if(!namea.matches("[0-9|a-z|A-Z|ㄱ-ㅎ|ㅏ-ㅣ|가-힝| ]*")) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(userdataupdate.this);
                    builder.setTitle("닉네임에는 특수문자 및 공백를 넣을수 없습니다!");
                    builder.setNegativeButton("예", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            nicknameagain.setText("");
                            nicknameagain.setFocusable(true);
                        }
                    });
                    builder.create();
                    builder.show();
                }
                else {
                    nicknameupdate(id2,namea);
                }
            }
        });
        btnupdatetel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                id1 = inputid1.getText().toString();
                tel = inputtel.getText().toString();
                if(tel.isEmpty()) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(userdataupdate.this);
                    builder.setTitle("전화번호를 입력해주십시오!");
                    builder.setNegativeButton("예", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            inputtel.setText("");
                            inputtel.setFocusable(true);
                        }
                    });
                    builder.create();
                    builder.show();
                }
                else if(!namea.matches("[a-z|A-Z|ㄱ-ㅎ|ㅏ-ㅣ|가-힝| ]*")) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(userdataupdate.this);
                    builder.setTitle("숫자만 입력할수있습니다!");
                    builder.setNegativeButton("예", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            inputtel.setText("");
                            inputtel.setFocusable(true);
                        }
                    });
                    builder.create();
                    builder.show();
                }
                else {
                    telupdate(tel,id1);
                }
            }
        });
    }

    public void idupdate(String idd, String idd1) {
        new Thread() {
            @Override
            public void run() {
                try {
                    URL seturl = new URL("Http://10.0.2.2/idupdate.php/");
                    HttpURLConnection http;
                    http = (HttpURLConnection) seturl.openConnection();
                    http.setDefaultUseCaches(false);
                    http.setDoInput(true);
                    http.setRequestMethod("POST");
                    http.setRequestProperty("content-type", "application/x-www-form-urlencoded");
                    StringBuffer buffer = new StringBuffer();
                    buffer.append("name").append("=").append(idd).append("/").append(idd1);
                    OutputStreamWriter out = new OutputStreamWriter(http.getOutputStream(), "UTF-8");
                    out.write(buffer.toString());
                    out.flush();

                    InputStreamReader tmp = new InputStreamReader(http.getInputStream(), "UTF-8");
                    BufferedReader reader = new BufferedReader(tmp);
                    StringBuilder builder = new StringBuilder();
                    String str;
                    while ((str = reader.readLine()) != null) {
                        builder.append(str);
                    }
                    String ResultData = builder.toString();
                    final String[] Result = ResultData.split("/");
                    handler2.post(new Runnable() {
                        @Override
                        public void run() {
                            AlertDialog.Builder builder = new AlertDialog.Builder(userdataupdate.this);
                            builder.setTitle("성공적으로 수정하였습니다! 앱을재시작해주십시오");
                            builder.setNegativeButton("예", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    finishAffinity();
                                }
                            });
                            builder.create();
                            builder.show();
                        }
                    });

                } catch (Exception e) {
                    Log.e("dataInsert()", "지정에러발생", e);
                }
            }
        }.start();
    }
    public void pwupdate(String idd1, String pwd1) {
        new Thread() {
            @Override
            public void run() {
                try {
                    URL seturl = new URL("Http://10.0.2.2/pwupdate.php/");
                    HttpURLConnection http;
                    http = (HttpURLConnection) seturl.openConnection();
                    http.setDefaultUseCaches(false);
                    http.setDoInput(true);
                    http.setRequestMethod("POST");
                    http.setRequestProperty("content-type", "application/x-www-form-urlencoded");
                    StringBuffer buffer = new StringBuffer();
                    buffer.append("name").append("=").append(idd1).append("/").append(pwd1);
                    OutputStreamWriter out = new OutputStreamWriter(http.getOutputStream(), "UTF-8");
                    out.write(buffer.toString());
                    out.flush();

                    InputStreamReader tmp = new InputStreamReader(http.getInputStream(), "UTF-8");
                    BufferedReader reader = new BufferedReader(tmp);
                    StringBuilder builder = new StringBuilder();
                    String str;
                    while ((str = reader.readLine()) != null) {
                        builder.append(str);
                    }
                    String ResultData = builder.toString();
                    final String[] Result = ResultData.split("/");
                    handler2.post(new Runnable() {
                        @Override
                        public void run() {
                            AlertDialog.Builder builder = new AlertDialog.Builder(userdataupdate.this);
                            builder.setTitle("성공적으로 수정하였습니다! 앱을재시작해주십시오");
                            builder.setNegativeButton("예", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    finishAffinity();
                                }
                            });
                            builder.create();
                            builder.show();
                        }
                    });

                } catch (Exception e) {
                    Log.e("dataInsert()", "지정에러발생", e);
                }
            }
        }.start();
    }
    public void nicknameupdate(String idd2, String name1) {
        new Thread() {
            @Override
            public void run() {
                try {
                    URL seturl = new URL("Http://10.0.2.2/nicknameupdate.php/");
                    HttpURLConnection http;
                    http = (HttpURLConnection) seturl.openConnection();
                    http.setDefaultUseCaches(false);
                    http.setDoInput(true);
                    http.setRequestMethod("POST");
                    http.setRequestProperty("content-type", "application/x-www-form-urlencoded");
                    StringBuffer buffer = new StringBuffer();
                    buffer.append("name").append("=").append(idd2).append("/").append(name1);
                    OutputStreamWriter out = new OutputStreamWriter(http.getOutputStream(), "UTF-8");
                    out.write(buffer.toString());
                    out.flush();

                    InputStreamReader tmp = new InputStreamReader(http.getInputStream(), "UTF-8");
                    BufferedReader reader = new BufferedReader(tmp);
                    StringBuilder builder = new StringBuilder();
                    String str;
                    while ((str = reader.readLine()) != null) {
                        builder.append(str);
                    }
                    String ResultData = builder.toString();
                    final String[] Result = ResultData.split("/");
                    handler2.post(new Runnable() {
                        @Override
                        public void run() {
                            AlertDialog.Builder builder = new AlertDialog.Builder(userdataupdate.this);
                            builder.setTitle("성공적으로 수정하였습니다! 앱을재시작해주십시오");
                            builder.setNegativeButton("예", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    finishAffinity();
                                }
                            });
                            builder.create();
                            builder.show();
                        }
                    });

                } catch (Exception e) {
                    Log.e("dataInsert()", "지정에러발생", e);
                }
            }
        }.start();
    }
    public void telupdate(String teld,String idd3) {
        new Thread() {
            @Override
            public void run() {
                try {
                    URL seturl = new URL("Http://10.0.2.2/telupdate.php/");
                    HttpURLConnection http;
                    http = (HttpURLConnection) seturl.openConnection();
                    http.setDefaultUseCaches(false);
                    http.setDoInput(true);
                    http.setRequestMethod("POST");
                    http.setRequestProperty("content-type", "application/x-www-form-urlencoded");
                    StringBuffer buffer = new StringBuffer();
                    buffer.append("name").append("=").append(teld).append("/").append(idd3);
                    OutputStreamWriter out = new OutputStreamWriter(http.getOutputStream(), "UTF-8");
                    out.write(buffer.toString());
                    out.flush();

                    InputStreamReader tmp = new InputStreamReader(http.getInputStream(), "UTF-8");
                    BufferedReader reader = new BufferedReader(tmp);
                    StringBuilder builder = new StringBuilder();
                    String str;
                    while ((str = reader.readLine()) != null) {
                        builder.append(str);
                    }
                    String ResultData = builder.toString();
                    final String[] Result = ResultData.split("/");
                    handler2.post(new Runnable() {
                        @Override
                        public void run() {
                            AlertDialog.Builder builder = new AlertDialog.Builder(userdataupdate.this);
                            builder.setTitle("성공적으로 수정하였습니다! 앱을재시작해주십시오");
                            builder.setNegativeButton("예", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    finishAffinity();
                                }
                            });
                            builder.create();
                            builder.show();
                        }
                    });

                } catch (Exception e) {
                    Log.e("dataInsert()", "지정에러발생", e);
                }
            }
        }.start();
    }
    public void idcheck(String checkid) {
        new Thread() {
            @Override
            public void run() {
                try {
                    URL seturl = new URL("Http://10.0.2.2/useridcheck.php/");
                    HttpURLConnection http;
                    http = (HttpURLConnection) seturl.openConnection();
                    http.setDefaultUseCaches(false);
                    http.setDoInput(true);
                    http.setRequestMethod("POST");
                    http.setRequestProperty("content-type", "application/x-www-form-urlencoded");
                    StringBuffer buffer = new StringBuffer();
                    buffer.append("name").append("=").append(checkid);
                    OutputStreamWriter out = new OutputStreamWriter(http.getOutputStream(), "UTF-8");
                    out.write(buffer.toString());
                    out.flush();
                    InputStreamReader tmp = new InputStreamReader(http.getInputStream(), "UTF-8");
                    BufferedReader reader = new BufferedReader(tmp);
                    StringBuilder builder = new StringBuilder();
                    String str;
                    while ((str = reader.readLine()) != null) {
                        builder.append(str);
                    }
                    String ResultData = builder.toString();
                    final String[] Result = ResultData.split("/");
                    handler2.post(new Runnable() {
                        @Override
                        public void run() {
                            if(Result[0].equals(ida)){
                                Toast.makeText(userdataupdate.this, "해당 ID는 사용중인 ID입니다!", Toast.LENGTH_SHORT).show();

                            }
                            else {
                                idupdate(id,ida);
                            }
                        }
                    });
                } catch (Exception e) {
                    Log.e("dataselect()", "지정에러발생", e);
                }
            }
        }.start();
    }
}