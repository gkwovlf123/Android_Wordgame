package com.example.myappproject;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.util.SparseBooleanArray;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;

public class uesrstat extends AppCompatActivity {
    Button btnstatdel;
    ListView listView;
    statadapter statadapter;
    Handler handler2 = new Handler();
    String id1,id2;
    boolean ischecked = false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_uesrstat);
        Intent intent = getIntent();
        id1 = intent.getStringExtra("userid");
        listselect(id1);
        statadapter = new statadapter();
        listView = findViewById(R.id.statlist);
        listView.setAdapter(statadapter);

        btnstatdel = findViewById(R.id.btndelstat);
        btnstatdel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(uesrstat.this);
                builder.setTitle("정말 삭제하시겠습니까?");
                builder.setPositiveButton("아니오", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(uesrstat.this, "취소되었습니다", Toast.LENGTH_SHORT).show();
                    }
                });
                builder.setNegativeButton("예", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if(ischecked==false) {
                            AlertDialog.Builder builder = new AlertDialog.Builder(uesrstat.this);
                            builder.setTitle("항목을 선택해주세요!");
                            builder.setNegativeButton("예", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                }
                            });
                            builder.create();
                            builder.show();
                        }
                        else {
                            listdelete(id2);
                            SparseBooleanArray checkedItems = listView.getCheckedItemPositions();
                            int count = statadapter.getCount();
                            for (int i = count - 1; i >= 0; i--) {
                                if (checkedItems.get(i)) {
                                    statadapter.remove(i);
                                }
                            }
                            // 모든 선택 상태 초기화.
                            statadapter.notifyDataSetChanged();
                        }
                    }
                });
                builder.create();
                builder.show();
            }
        });
    }
    public void listselect(String idd) {
        new Thread() {
            @Override
            public void run() {
                try {
                    URL seturl = new URL("Http://10.0.2.2/statlistselect.php/");
                    HttpURLConnection http;
                    http = (HttpURLConnection) seturl.openConnection();
                    http.setDefaultUseCaches(false);
                    http.setDoInput(true);
                    http.setRequestMethod("POST");
                    http.setRequestProperty("content-type", "application/x-www-form-urlencoded");
                    StringBuffer buffer = new StringBuffer();
                    buffer.append("name").append("=").append(idd);
                    OutputStreamWriter out = new OutputStreamWriter(http.getOutputStream(), "UTF-8");
                    out.write(buffer.toString());
                    out.flush();

                    InputStreamReader tmp = new InputStreamReader(http.getInputStream(), "UTF-8");
                    BufferedReader reader = new BufferedReader(tmp);
                    StringBuilder builder = new StringBuilder();
                    String str;
                    while ((str = reader.readLine()) != null) {
                        builder.append(str);
                        builder.append("\n");
                    }
                    String ResultData = builder.toString();
                    final String[] Result = ResultData.split("#");
                    final int count = Result.length;
                    handler2.post(new Runnable() {
                        @Override
                        public void run() {
                            if(count==1) {
                                AlertDialog.Builder builder = new AlertDialog.Builder(uesrstat.this);
                                builder.setTitle("리스트를 불러오지 못했습니다");
                                builder.setNegativeButton("예", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {

                                    }
                                });
                                builder.create();
                                builder.show();
                            }
                            else {
                                statadapter.itemclear();
                                for (int i = 1; i < count; i++) {
                                    final String[] Result2 = Result[i].split("/");
                                    statadapter.additem(Result2[0],"정답:"+Result2[1],"오답:"+Result2[2],"날짜:"+Result2[3]);
                                }
                                listView.setAdapter(statadapter);
                                listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                                    @Override
                                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                                        statlist item = (statlist)parent.getItemAtPosition(position);
                                        id2 = item.getDate();
                                        ischecked = true;
                                    }
                                });
                            }
                        }
                    });

                } catch (Exception e) {
                    Log.e("dataselect()", "지정에러발생", e);
                }
            }
        }.start();
    }
    public void listdelete(String idd) {
        new Thread() {
            @Override
            public void run() {
                try {
                    URL seturl = new URL("Http://10.0.2.2/statlistdelete.php/");
                    HttpURLConnection http;
                    http = (HttpURLConnection) seturl.openConnection();
                    http.setDefaultUseCaches(false);
                    http.setDoInput(true);
                    http.setRequestMethod("POST");
                    http.setRequestProperty("content-type", "application/x-www-form-urlencoded");
                    StringBuffer buffer = new StringBuffer();
                    buffer.append("name").append("=").append(idd);
                    OutputStreamWriter out = new OutputStreamWriter(http.getOutputStream(), "UTF-8");
                    out.write(buffer.toString());
                    out.flush();

                    InputStreamReader tmp = new InputStreamReader(http.getInputStream(), "UTF-8");
                    BufferedReader reader = new BufferedReader(tmp);
                    StringBuilder builder = new StringBuilder();
                    String ResultData = builder.toString();
                    final String[] Result = ResultData.split("/");
                    handler2.post(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(uesrstat.this, "해당정보가 삭제되었습니다", Toast.LENGTH_SHORT).show();
                        }
                    });

                } catch (Exception e) {
                    Log.e("dataInsert()", "지정에러발생", e);
                }
            }
        }.start();
    }
}