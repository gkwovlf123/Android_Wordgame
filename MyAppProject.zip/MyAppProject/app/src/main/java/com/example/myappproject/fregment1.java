package com.example.myappproject;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;

public class fregment1 extends Fragment {
    String id,pw;
    private Context context;
    Handler handler2 = new Handler();
    EditText edsignid, edsignpw;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        ViewGroup rootview = (ViewGroup) inflater.inflate(R.layout.activity_fregment1, container, false);
        context = container.getContext();
        Button btnlogin = rootview.findViewById(R.id.btnsignup);
        edsignid = rootview.findViewById(R.id.edsignupinputid);
        edsignpw = rootview.findViewById(R.id.edsignupinputpw);
        btnlogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                id = edsignid.getText().toString();
                pw = edsignpw.getText().toString();
                if(id.isEmpty()) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                    builder.setTitle("ID를 입력해주세요!");
                    builder.setNegativeButton("확인", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                        }
                    });
                    builder.create();
                    builder.show();
                }
                else if(pw.isEmpty()) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                    builder.setTitle("PW를 입력해주세요!");
                    builder.setNegativeButton("확인", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                        }
                    });
                    builder.create();
                    builder.show();
                }
                else {
                    login(id,pw);
                }
            }
        });
        return rootview;
    }
    public void login(String idd, String pwd) {
        new Thread() {
            @Override
            public void run() {
                try {
                    URL seturl = new URL("Http://10.0.2.2/login.php/");
                    HttpURLConnection http;
                    http = (HttpURLConnection) seturl.openConnection();
                    http.setDefaultUseCaches(false);
                    http.setDoInput(true);
                    http.setRequestMethod("POST");
                    http.setRequestProperty("content-type", "application/x-www-form-urlencoded");
                    StringBuffer buffer = new StringBuffer();
                    buffer.append("name").append("=").append(idd).append("/").append(pwd);
                    OutputStreamWriter out = new OutputStreamWriter(http.getOutputStream(), "UTF-8");
                    out.write(buffer.toString());
                    out.flush();

                    InputStreamReader tmp = new InputStreamReader(http.getInputStream(), "UTF-8");
                    BufferedReader reader = new BufferedReader(tmp);
                    StringBuilder builder = new StringBuilder();
                    String str;
                    while ((str = reader.readLine()) != null) {
                        builder.append(str);
                    }
                    String ResultData = builder.toString();
                    final String[] Result = ResultData.split("/");
                    handler2.post(new Runnable() {
                        @Override
                        public void run() {
                            id = edsignid.getText().toString();
                            pw = edsignpw.getText().toString();
                            if(Result[0].equals(id) && Result[1].equals(pw) && Result[2].equals("1")){
                                AlertDialog.Builder builder2 = new AlertDialog.Builder(getActivity());
                                builder2.setTitle("관리자계정으로 접속합니다");
                                builder2.setNegativeButton("확인", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        Toast.makeText(context, Result[0]+"님 환영합니다", Toast.LENGTH_SHORT).show();
                                        Intent intent = new Intent(getActivity(),adminmain.class);
                                        intent.putExtra("adminid",id);
                                        startActivity(intent);
                                    }
                                });
                                builder2.create();
                                builder2.show();
                            }
                            else if(Result[0].equals(id) && Result[1].equals(pw) && Result[2].equals("0")) {
                                AlertDialog.Builder builder1 = new AlertDialog.Builder(getActivity());
                                builder1.setTitle("로그인 성공");
                                builder1.setNegativeButton("확인", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        Toast.makeText(context, Result[0]+"님 환영합니다", Toast.LENGTH_SHORT).show();
                                        Intent intent = new Intent(getActivity(),usermain.class);
                                        intent.putExtra("userid",id);
                                        startActivity(intent);
                                    }
                                });
                                builder1.create();
                                builder1.show();
                            }
                            else {
                                AlertDialog.Builder builder1 = new AlertDialog.Builder(getActivity());
                                builder1.setTitle("로그인 실패");
                                builder1.setNegativeButton("확인", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                    }
                                });
                                builder1.create();
                                builder1.show();
                            }
                        }
                    });
                } catch (Exception e) {
                    Log.e("dataselect()", "지정에러발생", e);
                }
            }
        }.start();
    }
}