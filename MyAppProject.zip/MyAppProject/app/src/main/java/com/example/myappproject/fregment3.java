package com.example.myappproject;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;

public class fregment3 extends Fragment {
    Button btnfoundid, btnfoundpw;
    EditText edfoundid, edfoundpw, edfoundidtel, edfoundpwtel;
    String usercode, id, tel,tel2;
    Handler handler2 = new Handler();
    private Context context;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        ViewGroup rootview = (ViewGroup) inflater.inflate(R.layout.activity_fregment3,container,false);
        context = container.getContext();
        ActivityCompat.requestPermissions((Activity) context,new String[]{Manifest.permission.SEND_SMS},1);
        btnfoundid = rootview.findViewById(R.id.btnfoundid);
        btnfoundpw = rootview.findViewById(R.id.btnfoundpw);
        edfoundid = rootview.findViewById(R.id.edinputfoundid);
        edfoundpw = rootview.findViewById(R.id.edinputfoundpw);
        edfoundidtel = rootview.findViewById(R.id.edinputfoundid2);
        edfoundpwtel = rootview.findViewById(R.id.edinputfoundpw2);
        btnfoundid.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                usercode = edfoundid.getText().toString();
                tel = edfoundidtel.getText().toString();
                dataselect(usercode);
            }
        });
        btnfoundpw.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                id = edfoundpw.getText().toString();
                tel2 = edfoundpwtel.getText().toString();
                if(id=="admin") {
                    AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                    builder.setTitle("해당 ID는 찾을 수 없습니다!");
                    builder.setNegativeButton("예", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                        }
                    });
                    builder.create();
                    builder.show();
                }
                else {
                    foundpw(id);
                }
            }
        });
        return rootview;
    }
    public void dataselect(String usercoded) {
        new Thread() {
            @Override
            public void run() {
                try {
                    URL seturl = new URL("Http://10.0.2.2/foundid.php/");
                    HttpURLConnection http;
                    http = (HttpURLConnection) seturl.openConnection();
                    http.setDefaultUseCaches(false);
                    http.setDoInput(true);
                    http.setRequestMethod("POST");
                    http.setRequestProperty("content-type", "application/x-www-form-urlencoded");
                    StringBuffer buffer = new StringBuffer();
                    buffer.append("name").append("=").append(usercoded);
                    OutputStreamWriter out = new OutputStreamWriter(http.getOutputStream(), "UTF-8");
                    out.write(buffer.toString());
                    out.flush();
                    InputStreamReader tmp = new InputStreamReader(http.getInputStream(), "UTF-8");
                    BufferedReader reader = new BufferedReader(tmp);
                    StringBuilder builder = new StringBuilder();
                    String str;
                    while ((str = reader.readLine()) != null) {
                        builder.append(str);
                    }
                    String ResultData = builder.toString();
                    final String[] Result = ResultData.split("/");
                    handler2.post(new Runnable() {
                        @Override
                        public void run() {
                            usercode = edfoundid.getText().toString();
                            tel = edfoundidtel.getText().toString();
                            if (Result[0].equals(usercode)) {
                                SendSMS(tel,"ID는 " + Result[1] + "입니다!");
                                Toast.makeText(context, "ID는" + Result[1] + "입니다!", Toast.LENGTH_SHORT).show();
                            } else {
                                Toast.makeText(context, "유저코드가 맞지않습니다", Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
                } catch (Exception e) {
                    Log.e("dataselect()", "지정에러발생", e);
                }
            }
        }.start();
    }
    public void SendSMS(String phonenumber, String Msgbox) {
        android.telephony.SmsManager sms=android.telephony.SmsManager.getDefault();
        sms.sendTextMessage(phonenumber, null, Msgbox, null, null);
    }
    public void foundpw(String pwd) {
        new Thread() {
            @Override
            public void run() {
                try {
                    URL seturl = new URL("Http://10.0.2.2/foundpw.php/");
                    HttpURLConnection http;
                    http = (HttpURLConnection) seturl.openConnection();
                    http.setDefaultUseCaches(false);
                    http.setDoInput(true);
                    http.setRequestMethod("POST");
                    http.setRequestProperty("content-type", "application/x-www-form-urlencoded");
                    StringBuffer buffer = new StringBuffer();
                    buffer.append("name").append("=").append(pwd);
                    OutputStreamWriter out = new OutputStreamWriter(http.getOutputStream(), "UTF-8");
                    out.write(buffer.toString());
                    out.flush();
                    InputStreamReader tmp = new InputStreamReader(http.getInputStream(), "UTF-8");
                    BufferedReader reader = new BufferedReader(tmp);
                    StringBuilder builder = new StringBuilder();
                    String str;
                    while ((str = reader.readLine()) != null) {
                        builder.append(str);
                    }
                    String ResultData = builder.toString();
                    final String[] Result = ResultData.split("/");
                    handler2.post(new Runnable() {
                        @Override
                        public void run() {
                            id = edfoundpw.getText().toString();
                            tel2 = edfoundpwtel.getText().toString();
                            if (Result[0].equals(id)) {
                                SendSMS(tel2,"패스워드는 " + Result[1] + "입니다!");
                                Toast.makeText(context, "패스워드는" + Result[1] + "입니다!", Toast.LENGTH_SHORT).show();
                            } else {
                                Toast.makeText(context, "ID가 맞지않습니다", Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
                } catch (Exception e) {
                    Log.e("dataselect()", "지정에러발생", e);
                }
            }
        }.start();
    }
}