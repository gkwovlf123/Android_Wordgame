package com.example.myappproject;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;

public class wordappend extends AppCompatActivity {
    EditText edinputeng, editinputkor;
    Button btnappend;
    String eng, kor, temp, theme;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wordappend);
        Spinner spinner = findViewById(R.id.spinner);
        btnappend = findViewById(R.id.btnappend);
        edinputeng = findViewById(R.id.edeng);
        editinputkor = findViewById(R.id.edkor);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,R.array.word_array, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(wordappend.this, parent.getItemAtPosition(position).toString(), Toast.LENGTH_SHORT).show();
                temp = parent.getItemAtPosition(position).toString();
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        btnappend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                eng = edinputeng.getText().toString();
                kor = editinputkor.getText().toString();
                theme = temp;
                if(eng.isEmpty() && kor.isEmpty()) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(wordappend.this);
                    builder.setTitle("단어를 입력해주세요!");
                    builder.setNegativeButton("예", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            edinputeng.setFocusable(true);
                            editinputkor.setFocusable(true);
                        }
                    });
                    builder.create();
                    builder.show();
                }
                else if(theme.isEmpty()){
                    AlertDialog.Builder builder = new AlertDialog.Builder(wordappend.this);
                    builder.setTitle("단어 테마를 선택해주세요!");
                    builder.setNegativeButton("예", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                        }
                    });
                    builder.create();
                    builder.show();
                }
                else {
                    wordinsert(theme,eng,kor);
                    Toast.makeText(wordappend.this, "성공적으로 등록되었습니다!", Toast.LENGTH_SHORT).show();
                    edinputeng.setText("");
                    editinputkor.setText("");
                }
            }
        });


    }
    public void wordinsert(String theme, String eng, String kor) {
        new Thread() {
            @Override
            public void run() {
                try {
                    URL seturl = new URL("Http://10.0.2.2/wordinsert.php/");
                    HttpURLConnection http;
                    http = (HttpURLConnection) seturl.openConnection();
                    http.setDefaultUseCaches(false);
                    http.setDoInput(true);
                    http.setRequestMethod("POST");
                    http.setRequestProperty("content-type", "application/x-www-form-urlencoded");
                    StringBuffer buffer = new StringBuffer();
                    buffer.append("name").append("=").append(theme).append("/").append(eng).append("/").append(kor).append("/");
                    OutputStreamWriter out = new OutputStreamWriter(http.getOutputStream(), "UTF-8");
                    out.write(buffer.toString());
                    out.flush();

                    InputStreamReader tmp = new InputStreamReader(http.getInputStream(), "UTF-8");
                    final BufferedReader reader = new BufferedReader(tmp);
                    while (reader.readLine() != null) {
                        System.out.println(reader.readLine());
                    }
                } catch (Exception e) {
                    Log.e("dataInsert()", "지정에러발생", e);
                }
            }
        }.start();
    }
}