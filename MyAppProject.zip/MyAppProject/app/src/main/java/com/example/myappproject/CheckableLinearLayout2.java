package com.example.myappproject;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.CheckBox;
import android.widget.Checkable;
import android.widget.LinearLayout;

import androidx.annotation.Nullable;

public class CheckableLinearLayout2 extends LinearLayout implements Checkable {
    public CheckableLinearLayout2(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
    }
    @Override
    public void setChecked(boolean checked) {
        CheckBox checkBox = findViewById(R.id.checkBox3);
        if (checkBox.isChecked() != checked) {
            checkBox.setChecked(checked) ;
        }
    }

    @Override
    public boolean isChecked() {
        CheckBox checkBox = findViewById(R.id.checkBox3);
        return checkBox.isChecked();
    }

    @Override
    public void toggle() {
        CheckBox checkBox = findViewById(R.id.checkBox3);
        setChecked(checkBox.isChecked() ? false : true) ;
    }
}
