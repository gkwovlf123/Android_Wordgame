package com.example.myappproject;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class worddeleteadapter extends BaseAdapter {
    ArrayList<worddeleteitem> List = new ArrayList<>();
    @Override
    public int getCount() {
        return List.size();
    }

    @Override
    public Object getItem(int position) {
        return List.get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        final int pos = position;
        final Context context = parent.getContext();
        if(convertView==null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(R.layout.worddeletelayout,parent,false);
        }
        TextView txtid =  convertView.findViewById(R.id.textView5);
        TextView txtname =  convertView.findViewById(R.id.textView6);
        TextView txtanswer =  convertView.findViewById(R.id.textView8);
        worddeleteitem worddeleteitem = List.get(position);
        txtid.setText(worddeleteitem.getWordnum());
        txtname.setText(worddeleteitem.getName());
        txtanswer.setText(worddeleteitem.getAnswer());
        return convertView;
    }
    public void additem(String num, String name, String answer) {
        worddeleteitem item = new worddeleteitem();
        item.setWordnum(num);
        item.setName(name);
        item.setAnswer(answer);
        List.add(item);
    }
    public void itemclear() {
        List.clear();
    }
    public void remove(int position) {
        List.remove(position);
    }
}
