package com.example.myappproject;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.CheckBox;
import android.widget.Checkable;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.Toast;

import androidx.annotation.Nullable;

public class CheckableLinearLayout extends LinearLayout implements Checkable {
    public CheckableLinearLayout(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
    }
    @Override
    public void setChecked(boolean checked) {
        CheckBox checkBox = findViewById(R.id.checkBox);
        if (checkBox.isChecked() != checked) {
            checkBox.setChecked(checked) ;
        }
    }

    @Override
    public boolean isChecked() {
        CheckBox checkBox = findViewById(R.id.checkBox);
        return checkBox.isChecked();
    }

    @Override
    public void toggle() {
        CheckBox checkBox = findViewById(R.id.checkBox);
        setChecked(checkBox.isChecked() ? false : true) ;
    }
}
