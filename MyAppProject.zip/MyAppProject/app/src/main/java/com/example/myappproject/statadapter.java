package com.example.myappproject;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class statadapter extends BaseAdapter {
    ArrayList<statlist> List = new ArrayList<statlist>();
    public statadapter() {

    }
    @Override
    public int getCount() {
        return List.size();
    }

    @Override
    public Object getItem(int position) {

        return List.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        final int pos = position;
        final Context context = parent.getContext();
        if(convertView==null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(R.layout.statitemlayout,parent,false);
        }
        TextView txtdate =  convertView.findViewById(R.id.statid);
        TextView txttheme =  convertView.findViewById(R.id.statdate);
        TextView txtanswer =  convertView.findViewById(R.id.statanswer);
        TextView txtwronganswer =  convertView.findViewById(R.id.statwronganswer);
        statlist statlist = List.get(position);
        txtdate.setText(statlist.getDate());
        txttheme.setText(statlist.getTheme());
        txtanswer.setText(statlist.getAnswer());
        txtwronganswer.setText(statlist.getWronganswer());
        return convertView;
    }
    public void additem(String id, String answer, String wronganswer, String date) {
        statlist item = new statlist();
        item.setDate(id);
        item.setTheme(answer);
        item.setAnswer(wronganswer);
        item.setWronganswer(date);
        List.add(item);
    }
    public void itemclear() {
        List.clear();
    }
    public void remove(int postion) {
        List.remove(postion);
    }
}
