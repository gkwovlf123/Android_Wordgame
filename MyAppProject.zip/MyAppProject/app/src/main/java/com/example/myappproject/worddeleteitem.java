package com.example.myappproject;

public class worddeleteitem {
    String wordnum;
    String name;
    String answer;

    public String getWordnum() {
        return wordnum;
    }

    public void setWordnum(String wordnum) {
        this.wordnum = wordnum;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAnswer() {
        return answer;
    }

    public void setAnswer(String answer) {
        this.answer = answer;
    }
}
