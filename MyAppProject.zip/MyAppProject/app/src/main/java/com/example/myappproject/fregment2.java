package com.example.myappproject;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.telephony.SmsManager;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Random;

public class fregment2 extends Fragment {
    Button btnsign, btnsignback, btnsignid;
    EditText edinputid, edinputpw, edinputnickname, edinputphone;
    String id, pw,nickname,phone;
    int usercode,usercoder;
    boolean checkable = false;
    Handler handler2 = new Handler();
    private Context context;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        ViewGroup rootview = (ViewGroup) inflater.inflate(R.layout.activity_fregment2, container, false);

        btnsign = rootview.findViewById(R.id.btnsign);
        btnsignback = rootview.findViewById(R.id.btnsignback);
        btnsignid = rootview.findViewById(R.id.btnsignid);
        edinputid = rootview.findViewById(R.id.edsigninputid);
        edinputpw = rootview.findViewById(R.id.edsigninputpw);
        edinputnickname = rootview.findViewById(R.id.edsigninputnickname);
        edinputphone = rootview.findViewById(R.id.edsigninputphone);
        context = container.getContext();
        ActivityCompat.requestPermissions((Activity) context,new String[]{Manifest.permission.SEND_SMS},1);
        btnsign.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                id = edinputid.getText().toString();
                pw = edinputpw.getText().toString();
                nickname = edinputnickname.getText().toString();
                phone = edinputphone.getText().toString();
                usercoder = mkusercode();
                if(id.length()==0){
                    AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                    builder.setTitle("id가 입력되지 않았습니다!");
                    builder.setNegativeButton("예", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            edinputid.setFocusable(true);
                        }
                    });
                    builder.create();
                    builder.show();
                }
                else if(id.matches("[ ]*")) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                    builder.setTitle("id에는 공백이 있을 수 없습니다!");
                    builder.setNegativeButton("예", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            edinputid.setText("");
                            edinputid.setFocusable(true);
                        }
                    });
                    builder.create();
                    builder.show();
                }
                else if(id.length()<10 || id.length()>15){
                    AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                    builder.setTitle("id는 10자리 이상 15자리 이하만 입력할 수 있습니다!");
                    builder.setNegativeButton("예", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            edinputid.setText("");
                            edinputid.setFocusable(true);
                        }
                    });
                    builder.create();
                    builder.show();
                }
                else if(!id.matches("[0-9|a-z|A-Z| ]*")){
                    AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                    builder.setTitle("id에 특수문자 또는 한글은 입력할 수 없습니다!");
                    builder.setNegativeButton("예", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            edinputid.setText("");
                            edinputid.setFocusable(true);
                        }
                    });
                    builder.create();
                    builder.show();
                }
                else if(pw.length()==0){
                    AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                    builder.setTitle("pw가 입력되지 않았습니다!");
                    builder.setNegativeButton("예", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            edinputpw.setFocusable(true);
                        }
                    });
                    builder.create();
                    builder.show();
                }
                else if(pw.matches("[ ]*")) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                    builder.setTitle("pw에는 공백이 있을 수 없습니다!");
                    builder.setNegativeButton("예", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            edinputpw.setText("");
                            edinputpw.setFocusable(true);
                        }
                    });
                    builder.create();
                    builder.show();
                }
                else if(pw.matches("[ㄱ-ㅎ|ㅏ-ㅣ|가-힝| ]*")){
                    AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                    builder.setTitle("pw에 한글 및 공백은 입력할 수 없습니다!");
                    builder.setNegativeButton("예", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            edinputpw.setText("");
                            edinputpw.setFocusable(true);
                        }
                    });
                    builder.create();
                    builder.show();
                }
                else if(pw.length()<8 || pw.length()>20){
                    AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                    builder.setTitle("pw는 8자리 이상 20자리 이하만 입력할 수 있습니다!");
                    builder.setNegativeButton("예", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            edinputpw.setText("");
                            edinputpw.setFocusable(true);
                        }
                    });
                    builder.create();
                    builder.show();
                }
                else if(nickname.length()==0) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                    builder.setTitle("닉네임이 입력되지 않았습니다!");
                    builder.setNegativeButton("예", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            edinputnickname.setFocusable(true);
                        }
                    });
                    builder.create();
                    builder.show();
                }
                else if(nickname.matches("[ ]*")) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                    builder.setTitle("닉네임에는 공백이 있을 수 없습니다!");
                    builder.setNegativeButton("예", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            edinputnickname.setText("");
                            edinputnickname.setFocusable(true);
                        }
                    });
                    builder.create();
                    builder.show();
                }
                else if(nickname.length()>10){
                    AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                    builder.setTitle("닉네임은 10글자를 넘을수 없습니다!");
                    builder.setNegativeButton("예", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            edinputnickname.setText("");
                            edinputnickname.setFocusable(true);
                        }
                    });
                    builder.create();
                    builder.show();
                }
                else if(!nickname.matches("[0-9|a-z|A-Z|ㄱ-ㅎ|ㅏ-ㅣ|가-힝| ]*")) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                    builder.setTitle("닉네임에는 특수문자 및 공백를 넣을수 없습니다!");
                    builder.setNegativeButton("예", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            edinputnickname.setText("");
                            edinputnickname.setFocusable(true);
                        }
                    });
                    builder.create();
                    builder.show();
                }
                else if(checkable!=true) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                    builder.setTitle("ID 중복체크를 진행하거나 그 ID는 사용할 수 없습니다!");
                    builder.setNegativeButton("예", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                        }
                    });
                    builder.create();
                    builder.show();
                }
                else if(id=="admin"){
                    AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                    builder.setTitle("해당 ID는 사용할 수 없습니다!");
                    builder.setNegativeButton("예", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                        }
                    });
                    builder.create();
                    builder.show();
                }
                else if(phone.matches("[ㄱ-ㅎ|ㅏ-ㅣ|가-힝|a-z|A-Z ]*")){
                    AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                    builder.setTitle("전화번호란에는 숫자만 입력할 수 있습니다!");
                    builder.setNegativeButton("예", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            edinputphone.setText("");
                            edinputphone.setFocusable(true);
                        }
                    });
                    builder.create();
                    builder.show();
                }
                else {
                    id = edinputid.getText().toString();
                    pw = edinputpw.getText().toString();
                    nickname = edinputnickname.getText().toString();
                    phone = edinputphone.getText().toString();
                    SendSMS(phone,"회원가입 성공! 유저코드는" + usercode + "입니다!");
                    datainsert(id,pw,nickname,usercoder,phone);
                    Toast.makeText(context, "회원가입 성공! 유저코드 : " + usercode, Toast.LENGTH_SHORT).show();
                    edinputid.setText("");
                    edinputpw.setText("");
                    edinputnickname.setText("");
                    edinputphone.setText("");
                    checkable=false;
                }

            }
        });
        btnsignback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                edinputid.setText("");
                edinputpw.setText("");
                edinputnickname.setText("");
                edinputphone.setText("");
                checkable=false;
            }
        });
        btnsignid.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                id = edinputid.getText().toString();
                dataselect(id);
            }
        });
        return rootview;
    }

    public int mkusercode() {
        Random r = new Random();
        usercode = r.nextInt(10000);
        if(usercode<1000){
            while(true) {
                if(usercode<1000){
                    usercode = r.nextInt(10000);
                }
            }
        }
        return usercode;
    }
    public void SendSMS(String phonenumber, String Msgbox) {
        android.telephony.SmsManager sms=android.telephony.SmsManager.getDefault();
        sms.sendTextMessage(phonenumber, null, Msgbox, null, null);
    }

    public void datainsert(String idd, String pwd, String nicknamed, int usercoded, String phoned) {
        new Thread() {
            @Override
            public void run() {
                try {
                    URL seturl = new URL("Http://10.0.2.2/userinsert.php/");
                    HttpURLConnection http;
                    http = (HttpURLConnection)seturl.openConnection();
                    http.setDefaultUseCaches(false);
                    http.setDoInput(true);
                    http.setRequestMethod("POST");
                    http.setRequestProperty("content-type", "application/x-www-form-urlencoded");
                    StringBuffer buffer = new StringBuffer();
                    buffer.append("name").append("=").append(idd).append("/").append(pwd).append("/").append(nicknamed).append("/").append(usercoded).append("/").append(phoned);
                    OutputStreamWriter out = new OutputStreamWriter(http.getOutputStream(),"utf-8");
                    out.write(buffer.toString());
                    out.flush();
                    InputStreamReader tmp = new InputStreamReader(http.getInputStream(),"utf-8");
                    final BufferedReader reader = new BufferedReader(tmp);
                    while(reader.readLine()!=null){
                        System.out.println(reader.readLine());
                    }
                }catch (Exception e){
                    Log.e("dataInsert()","지정에러발생",e);
                }
            }
        }.start();
    }
    public void dataselect(String checkid) {
        new Thread() {
            @Override
            public void run() {
                try {
                    URL seturl = new URL("Http://10.0.2.2/useridcheck.php/");
                    HttpURLConnection http;
                    http = (HttpURLConnection) seturl.openConnection();
                    http.setDefaultUseCaches(false);
                    http.setDoInput(true);
                    http.setRequestMethod("POST");
                    http.setRequestProperty("content-type", "application/x-www-form-urlencoded");
                    StringBuffer buffer = new StringBuffer();
                    buffer.append("name").append("=").append(checkid);
                    OutputStreamWriter out = new OutputStreamWriter(http.getOutputStream(), "UTF-8");
                    out.write(buffer.toString());
                    out.flush();
                    InputStreamReader tmp = new InputStreamReader(http.getInputStream(), "UTF-8");
                    BufferedReader reader = new BufferedReader(tmp);
                    StringBuilder builder = new StringBuilder();
                    String str;
                    while ((str = reader.readLine()) != null) {
                        builder.append(str);
                    }
                    String ResultData = builder.toString();
                    final String[] Result = ResultData.split("/");
                    handler2.post(new Runnable() {
                        @Override
                        public void run() {
                            id = edinputid.getText().toString();
                            if(Result[0].equals(id)){
                                   Toast.makeText(context, "해당 ID는 중복입니다!", Toast.LENGTH_SHORT).show();
                                   checkable=false;
                            }
                            else {
                                Toast.makeText(context, "해당 ID는 사용하실 수 있습니다!", Toast.LENGTH_SHORT).show();
                                checkable = true;
                            }
                        }
                    });
                } catch (Exception e) {
                    Log.e("dataselect()", "지정에러발생", e);
                }
            }
        }.start();
    }
}