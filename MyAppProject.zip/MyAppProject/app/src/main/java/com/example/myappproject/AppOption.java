package com.example.myappproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.util.AndroidException;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TextView;

public class AppOption extends AppCompatActivity {
    TextView txtOptitle, txtbackgroundtitle;
    ImageButton btnback;
    ImageView imglightred,imgdarkred,imglightorange,imglightgreen,imgprimarydark,imgteal,imgcardview,imgwhite;
    TableLayout tableLayout;
    static boolean isadmin = false;
    static int color = 0;
    String id;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_app_option);
        imglightred = findViewById(R.id.imgcolor1);
        imgdarkred = findViewById(R.id.imgcolor2);
        imglightorange = findViewById(R.id.imgcolor3);
        imglightgreen = findViewById(R.id.imgcolor4);
        imgprimarydark = findViewById(R.id.imgcolor5);
        imgteal = findViewById(R.id.imgcolor6);
        imgcardview = findViewById(R.id.imgcolor7);
        imgwhite = findViewById(R.id.imgcolor8);
        tableLayout = findViewById(R.id.tablelayout1);
        txtOptitle = findViewById(R.id.txtOptitle);
        txtbackgroundtitle = findViewById(R.id.txtbackgroundtitle);
        btnback = findViewById(R.id.btnoptionback);
        id = usermain.id;
        btnback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(isadmin==false) {
                    Intent intent = new Intent(getApplicationContext(), usermain.class);
                    intent.putExtra("userid",id);
                    startActivity(intent);
                }
            }
        });
        imglightred.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                txtOptitle.setTextColor(Color.WHITE);
                txtbackgroundtitle.setTextColor(Color.WHITE);
                tableLayout.setBackground(imglightred.getBackground());
                color = 1;
            }
        });
        imgdarkred.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                txtOptitle.setTextColor(Color.WHITE);
                txtbackgroundtitle.setTextColor(Color.WHITE);
                tableLayout.setBackground(imgdarkred.getBackground());
                color = 2;
            }
        });
        imglightorange.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                txtOptitle.setTextColor(Color.BLACK);
                txtbackgroundtitle.setTextColor(Color.BLACK);
                tableLayout.setBackground(imglightorange.getBackground());
                color = 3;
            }
        });
        imglightgreen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                txtOptitle.setTextColor(Color.WHITE);
                txtbackgroundtitle.setTextColor(Color.WHITE);
                tableLayout.setBackground(imglightgreen.getBackground());
                color = 4;
            }
        });
        imgprimarydark.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                txtOptitle.setTextColor(Color.WHITE);
                txtbackgroundtitle.setTextColor(Color.WHITE);
                tableLayout.setBackground(imgprimarydark.getBackground());
                color = 5;
            }
        });
        imgteal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                txtOptitle.setTextColor(Color.WHITE);
                txtbackgroundtitle.setTextColor(Color.WHITE);
                tableLayout.setBackground(imgteal.getBackground());
                color = 6;
            }
        });
        imgcardview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                txtOptitle.setTextColor(Color.WHITE);
                txtbackgroundtitle.setTextColor(Color.WHITE);
                tableLayout.setBackground(imgcardview.getBackground());
                color = 7;
            }
        });
        imgwhite.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                txtOptitle.setTextColor(Color.BLACK);
                txtbackgroundtitle.setTextColor(Color.BLACK);
                tableLayout.setBackground(imgwhite.getBackground());
                color = 8;
            }
        });
    }
}