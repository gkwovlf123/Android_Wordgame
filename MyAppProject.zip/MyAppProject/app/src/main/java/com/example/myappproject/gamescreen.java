package com.example.myappproject;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TableLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;

public class gamescreen extends AppCompatActivity {
    String a,b,c, getTime,id1;
    Handler handler2 = new Handler();
    TextView title, collect, incollect, titlenum,txt14,txt15,txt18,txt19,txt24,txt25;
    Button btn1, btn2, btn3, btn4;
    boolean estr1=false, estr2=false, estr3=false,estr4=false;
    int i = 0, j = 0, k = 1;
    ImageButton btnback;
    TableLayout table1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gamescreen);
        Intent intent = getIntent();
        id1 = intent.getStringExtra("userid");
        title = findViewById(R.id.questiontitle);
        btn1 = findViewById(R.id.btn1);
        btn2 = findViewById(R.id.btn2);
        btn3 = findViewById(R.id.btn3);
        btn4 = findViewById(R.id.btn4);
        collect = findViewById(R.id.textView19);
        incollect = findViewById(R.id.textView25);
        titlenum = findViewById(R.id.textView14);
        btnback = findViewById(R.id.btngameback);
        table1 = findViewById(R.id.tableLayout2);
        txt14 = findViewById(R.id.textView14);
        txt15 = findViewById(R.id.textView15);
        txt18 = findViewById(R.id.textView18);
        txt19 = findViewById(R.id.textView19);
        txt24 = findViewById(R.id.textView24);
        txt25 = findViewById(R.id.textView25);
        if(AppOption.color==1) {
            table1.setBackgroundColor(Color.parseColor("#ffff4444"));
            txt14.setTextColor(Color.WHITE);
            txt15.setTextColor(Color.WHITE);
            txt18.setTextColor(Color.WHITE);
            txt19.setTextColor(Color.WHITE);
            txt24.setTextColor(Color.WHITE);
            txt25.setTextColor(Color.WHITE);
            title.setTextColor(Color.WHITE);
        }
        else if(AppOption.color==2) {
            table1.setBackgroundColor(Color.parseColor("#ffcc0000"));
            txt14.setTextColor(Color.WHITE);
            txt15.setTextColor(Color.WHITE);
            txt18.setTextColor(Color.WHITE);
            txt19.setTextColor(Color.WHITE);
            txt24.setTextColor(Color.WHITE);
            txt25.setTextColor(Color.WHITE);
            title.setTextColor(Color.WHITE);
        }
        else if(AppOption.color==3) {
            table1.setBackgroundColor(Color.parseColor("#ffffbb33"));
            txt14.setTextColor(Color.WHITE);
            txt15.setTextColor(Color.WHITE);
            txt18.setTextColor(Color.WHITE);
            txt19.setTextColor(Color.WHITE);
            txt24.setTextColor(Color.WHITE);
            txt25.setTextColor(Color.WHITE);
            title.setTextColor(Color.WHITE);
        }
        else if(AppOption.color==4) {
            table1.setBackgroundColor(Color.parseColor("#ff99cc00"));
            txt14.setTextColor(Color.WHITE);
            txt15.setTextColor(Color.WHITE);
            txt18.setTextColor(Color.WHITE);
            txt19.setTextColor(Color.WHITE);
            txt24.setTextColor(Color.WHITE);
            txt25.setTextColor(Color.WHITE);
        }
        else if(AppOption.color==5) {
            table1.setBackgroundColor(Color.parseColor("#3700b3"));
            txt14.setTextColor(Color.WHITE);
            txt15.setTextColor(Color.WHITE);
            txt18.setTextColor(Color.WHITE);
            txt19.setTextColor(Color.WHITE);
            txt24.setTextColor(Color.WHITE);
            txt25.setTextColor(Color.WHITE);
            title.setTextColor(Color.WHITE);
        }
        else if(AppOption.color==6) {
            table1.setBackgroundColor(Color.parseColor("#ff03dac5"));
            txt14.setTextColor(Color.WHITE);
            txt15.setTextColor(Color.WHITE);
            txt18.setTextColor(Color.WHITE);
            txt19.setTextColor(Color.WHITE);
            txt24.setTextColor(Color.WHITE);
            txt25.setTextColor(Color.WHITE);
            title.setTextColor(Color.WHITE);
        }
        else if(AppOption.color==7) {
            table1.setBackgroundColor(Color.parseColor("#ff424242"));
            txt14.setTextColor(Color.WHITE);
            txt15.setTextColor(Color.WHITE);
            txt18.setTextColor(Color.WHITE);
            txt19.setTextColor(Color.WHITE);
            txt24.setTextColor(Color.WHITE);
            txt25.setTextColor(Color.WHITE);
            title.setTextColor(Color.WHITE);
        }
        else if(AppOption.color==8) {
            table1.setBackgroundColor(Color.parseColor("#ffffffff"));
            txt14.setTextColor(Color.GRAY);
            txt15.setTextColor(Color.GRAY);
            txt18.setTextColor(Color.GRAY);
            txt19.setTextColor(Color.GRAY);
            txt24.setTextColor(Color.GRAY);
            txt25.setTextColor(Color.GRAY);
            title.setTextColor(Color.GRAY);
        }
        btnback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(gamescreen.this);
                builder.setTitle("이전화면으로 돌아갑니다");
                builder.setNegativeButton("예", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        finish();
                    }
                });
                builder.setPositiveButton("아니오", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                    }
                });
                builder.create();
                builder.show();
            }
        });
        long now = System.currentTimeMillis();
        Date mdate = new Date(now);
        SimpleDateFormat simpleDate = new SimpleDateFormat("yyyy-MM-dd");
        getTime = simpleDate.format(mdate);
        settitle();
    }
    public void settitle() {
        new Thread() {
            @Override
            public void run() {
                try {
                    URL seturl = new URL("Http://10.0.2.2/settitle.php/");
                    HttpURLConnection http;
                    http = (HttpURLConnection) seturl.openConnection();
                    http.setDefaultUseCaches(false);
                    http.setDoInput(true);
                    http.setRequestMethod("POST");
                    http.setRequestProperty("content-type", "application/x-www-form-urlencoded");
                    StringBuffer buffer = new StringBuffer();
                    buffer.append("name");
                    OutputStreamWriter out = new OutputStreamWriter(http.getOutputStream(), "UTF-8");
                    out.write(buffer.toString());
                    out.flush();

                    InputStreamReader tmp = new InputStreamReader(http.getInputStream(), "UTF-8");
                    BufferedReader reader = new BufferedReader(tmp);
                    StringBuilder builder = new StringBuilder();
                    String str;
                    while ((str = reader.readLine()) != null) {
                        builder.append(str);
                    }
                    String ResultData = builder.toString();
                    final String[] Result = ResultData.split("/");
                    handler2.post(new Runnable() {
                        @Override
                        public void run() {
                            title.setText(Result[0]);
                            Random random = new Random();
                            int num = random.nextInt(3);
                            if(num==0) {
                                btn1.setText(Result[1]);
                                estr1 = true;
                                btnselect2();
                                btnselect3();
                                btnselect4();
                                btn1.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        i++;
                                        k++;
                                        if(k==11){
                                            String answer = collect.getText().toString();
                                            String wrong = incollect.getText().toString();
                                            Toast.makeText(gamescreen.this, "데이터 등록 성공",Toast.LENGTH_SHORT).show();
                                            statinsert(answer,wrong,getTime,id1);
                                            finish();
                                        }
                                        c = Integer.toString(k);
                                        a = Integer.toString(i);
                                        titlenum.setText(c);
                                        collect.setText(a+"개");
                                        estr1 = false;
                                        settitle();
                                    }
                                });
                                btn2.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        j++;
                                        k++;
                                        if(k==11){
                                            String answer = collect.getText().toString();
                                            String wrong = incollect.getText().toString();
                                            Toast.makeText(gamescreen.this, "데이터 등록 성공",Toast.LENGTH_SHORT).show();
                                            statinsert(answer,wrong,getTime,id1);
                                            finish();
                                        }
                                        c = Integer.toString(k);
                                        b = Integer.toString(j);
                                        titlenum.setText(c);
                                        incollect.setText(b+"개");
                                        estr2 = false;
                                        settitle();
                                    }
                                });
                                btn3.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        j++;
                                        k++;
                                        if(k==11){
                                            String answer = collect.getText().toString();
                                            String wrong = incollect.getText().toString();
                                            Toast.makeText(gamescreen.this, "데이터 등록 성공",Toast.LENGTH_SHORT).show();
                                            statinsert(answer,wrong,getTime,id1);
                                            finish();
                                        }
                                        c = Integer.toString(k);
                                        titlenum.setText(c);
                                        b = Integer.toString(j);
                                        incollect.setText(b+"개");
                                        estr3 = false;
                                        settitle();
                                    }
                                });
                                btn4.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        j++;
                                        k++;
                                        if(k==11){
                                            String answer = collect.getText().toString();
                                            String wrong = incollect.getText().toString();
                                            Toast.makeText(gamescreen.this, "데이터 등록 성공",Toast.LENGTH_SHORT).show();
                                            statinsert(answer,wrong,getTime,id1);
                                            finish();
                                        }
                                        c = Integer.toString(k);
                                        titlenum.setText(c);
                                        b = Integer.toString(j);
                                        incollect.setText(b+"개");
                                        estr4 = false;
                                        settitle();
                                    }
                                });


                            }
                            else if(num==1) {
                                btn2.setText(Result[1]);
                                estr2 = true;
                                btnselect1();
                                btnselect3();
                                btnselect4();
                                btn2.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        i++;
                                        k++;
                                        if(k==11){
                                            String answer = collect.getText().toString();
                                            String wrong = incollect.getText().toString();
                                            Toast.makeText(gamescreen.this, "데이터 등록 성공",Toast.LENGTH_SHORT).show();
                                            statinsert(answer,wrong,getTime,id1);
                                            finish();
                                        }
                                        c = Integer.toString(k);
                                        titlenum.setText(c);
                                        a = Integer.toString(i);
                                        collect.setText(a+"개");
                                        estr2 = false;
                                        settitle();
                                    }
                                });
                                btn1.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        j++;
                                        k++;
                                        if(k==11){
                                            String answer = collect.getText().toString();
                                            String wrong = incollect.getText().toString();
                                            Toast.makeText(gamescreen.this, "데이터 등록 성공",Toast.LENGTH_SHORT).show();
                                            statinsert(answer,wrong,getTime,id1);
                                            finish();
                                        }
                                        c = Integer.toString(k);
                                        titlenum.setText(c);
                                        b = Integer.toString(j);
                                        incollect.setText(b+"개");
                                        estr1 = false;
                                        settitle();
                                    }
                                });
                                btn3.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        j++;
                                        k++;
                                        if(k==11){
                                            String answer = collect.getText().toString();
                                            String wrong = incollect.getText().toString();
                                            Toast.makeText(gamescreen.this, "데이터 등록 성공",Toast.LENGTH_SHORT).show();
                                            statinsert(answer,wrong,getTime,id1);
                                            finish();
                                        }
                                        c = Integer.toString(k);
                                        titlenum.setText(c);
                                        b = Integer.toString(j);
                                        incollect.setText(b+"개");
                                        estr3 = false;
                                        settitle();
                                    }
                                });
                                btn4.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        j++;
                                        k++;
                                        if(k==11){
                                            String answer = collect.getText().toString();
                                            String wrong = incollect.getText().toString();
                                            Toast.makeText(gamescreen.this, "데이터 등록 성공",Toast.LENGTH_SHORT).show();
                                            statinsert(answer,wrong,getTime,id1);
                                            finish();
                                        }
                                        c = Integer.toString(k);
                                        titlenum.setText(c);
                                        b = Integer.toString(j);
                                        incollect.setText(b+"개");
                                        estr4 = false;
                                        settitle();
                                    }
                                });

                            }
                            else if(num==2) {
                                btn3.setText(Result[1]);
                                estr3 = true;
                                btnselect1();
                                btnselect2();
                                btnselect4();
                                btn3.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        i++;
                                        k++;
                                        if(k==11){
                                            String answer = collect.getText().toString();
                                            String wrong = incollect.getText().toString();
                                            Toast.makeText(gamescreen.this, "데이터 등록 성공",Toast.LENGTH_SHORT).show();
                                            statinsert(answer,wrong,getTime,id1);
                                            finish();
                                        }
                                        c = Integer.toString(k);
                                        titlenum.setText(c);
                                        a = Integer.toString(i);
                                        collect.setText(a+"개");
                                        estr3 = false;
                                        settitle();
                                    }
                                });
                                btn1.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        j++;
                                        k++;
                                        if(k==11){
                                            String answer = collect.getText().toString();
                                            String wrong = incollect.getText().toString();
                                            Toast.makeText(gamescreen.this, "데이터 등록 성공",Toast.LENGTH_SHORT).show();
                                            statinsert(answer,wrong,getTime,id1);
                                            finish();
                                        }
                                        c = Integer.toString(k);
                                        titlenum.setText(c);
                                        b = Integer.toString(j);
                                        incollect.setText(b+"개");
                                        estr1 = false;
                                        settitle();
                                    }
                                });
                                btn2.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        j++;
                                        k++;
                                        if(k==11){
                                            String answer = collect.getText().toString();
                                            String wrong = incollect.getText().toString();
                                            Toast.makeText(gamescreen.this, "데이터 등록 성공",Toast.LENGTH_SHORT).show();
                                            statinsert(answer,wrong,getTime,id1);
                                            finish();
                                        }
                                        c = Integer.toString(k);
                                        titlenum.setText(c);
                                        b = Integer.toString(j);
                                        incollect.setText(b+"개");
                                        estr2 = false;
                                        settitle();
                                    }
                                });
                                btn4.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        j++;
                                        k++;
                                        if(k==11){
                                            String answer = collect.getText().toString();
                                            String wrong = incollect.getText().toString();
                                            Toast.makeText(gamescreen.this, "데이터 등록 성공",Toast.LENGTH_SHORT).show();
                                            statinsert(answer,wrong,getTime,id1);
                                            finish();
                                        }
                                        c = Integer.toString(k);
                                        titlenum.setText(c);
                                        b = Integer.toString(j);
                                        incollect.setText(b+"개");
                                        estr4 = false;
                                        settitle();
                                    }
                                });
                            }
                            else if(num==3) {
                                btn4.setText(Result[1]);
                                estr4 = true;
                                btnselect1();
                                btnselect2();
                                btnselect3();
                                btn4.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        i++;
                                        k++;
                                        if(k==11){
                                            String answer = collect.getText().toString();
                                            String wrong = incollect.getText().toString();
                                            Toast.makeText(gamescreen.this, "데이터 등록 성공",Toast.LENGTH_SHORT).show();
                                            statinsert(answer,wrong,getTime,id1);
                                            finish();
                                        }
                                        c = Integer.toString(k);
                                        titlenum.setText(c);
                                        a = Integer.toString(i);
                                        collect.setText(a+"개");
                                        estr4 = false;
                                        settitle();
                                    }
                                });
                                btn1.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        j++;
                                        k++;
                                        if(k==11){
                                            String answer = collect.getText().toString();
                                            String wrong = incollect.getText().toString();
                                            Toast.makeText(gamescreen.this, "데이터 등록 성공",Toast.LENGTH_SHORT).show();
                                            statinsert(answer,wrong,getTime,id1);
                                            finish();
                                        }
                                        c = Integer.toString(k);
                                        titlenum.setText(c);
                                        b = Integer.toString(j);
                                        incollect.setText(b+"개");
                                        estr1= false;
                                        settitle();
                                    }
                                });
                                btn2.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        j++;
                                        k++;
                                        if(k==11){
                                            String answer = collect.getText().toString();
                                            String wrong = incollect.getText().toString();
                                            Toast.makeText(gamescreen.this, "데이터 등록 성공",Toast.LENGTH_SHORT).show();
                                            statinsert(answer,wrong,getTime,id1);
                                            finish();
                                        }
                                        c = Integer.toString(k);
                                        titlenum.setText(c);
                                        b = Integer.toString(j);
                                        incollect.setText(b+"개");
                                        estr2 = false;
                                        settitle();
                                    }
                                });
                                btn3.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        j++;
                                        k++;
                                        if(k==11){
                                            String answer = collect.getText().toString();
                                            String wrong = incollect.getText().toString();
                                            Toast.makeText(gamescreen.this, "데이터 등록 성공",Toast.LENGTH_SHORT).show();
                                            statinsert(answer,wrong,getTime,id1);
                                            finish();
                                        }
                                        c = Integer.toString(k);
                                        titlenum.setText(c);
                                        b = Integer.toString(j);
                                        incollect.setText(b+"개");
                                        estr3 = false;
                                        settitle();
                                    }
                                });

                            }
                        }
                    });
                } catch (Exception e) {
                    Log.e("dataselect()", "지정에러발생", e);
                }
            }
        }.start();
    }
    public void btnselect1() {
        new Thread() {
            @Override
            public void run() {
                try {
                    URL seturl = new URL("Http://10.0.2.2/btnselect1.php/");
                    HttpURLConnection http;
                    http = (HttpURLConnection) seturl.openConnection();
                    http.setDefaultUseCaches(false);
                    http.setDoInput(true);
                    http.setRequestMethod("POST");
                    http.setRequestProperty("content-type", "application/x-www-form-urlencoded");
                    StringBuffer buffer = new StringBuffer();
                    buffer.append("name");
                    OutputStreamWriter out = new OutputStreamWriter(http.getOutputStream(), "UTF-8");
                    out.write(buffer.toString());
                    out.flush();

                    InputStreamReader tmp = new InputStreamReader(http.getInputStream(), "UTF-8");
                    BufferedReader reader = new BufferedReader(tmp);
                    StringBuilder builder = new StringBuilder();
                    String str;
                    while ((str = reader.readLine()) != null) {
                        builder.append(str);
                    }
                    String ResultData = builder.toString();
                    final String[] Result = ResultData.split("/");
                    handler2.post(new Runnable() {
                        @Override
                        public void run() {
                            if(estr1==true) {
                                Random random = new Random();
                                int num = random.nextInt(2);
                                if(num==0) {
                                    btn2.setText(Result[0]);
                                    estr2 = false;
                                }
                                else if(num==1) {
                                    btn3.setText(Result[0]);
                                    estr3 = false;
                                }
                                else if(num==2) {
                                    btn4.setText(Result[0]);
                                    estr4 = false;
                                }
                            }
                            else  {
                                btn1.setText(Result[0]);
                            }
                        }
                    });

                } catch (Exception e) {
                    Log.e("dataselect()", "지정에러발생", e);
                }
            }
        }.start();
    }
    public void btnselect2() {
        new Thread() {
            @Override
            public void run() {
                try {
                    URL seturl = new URL("Http://10.0.2.2/btnselect1.php/");
                    HttpURLConnection http;
                    http = (HttpURLConnection) seturl.openConnection();
                    http.setDefaultUseCaches(false);
                    http.setDoInput(true);
                    http.setRequestMethod("POST");
                    http.setRequestProperty("content-type", "application/x-www-form-urlencoded");
                    StringBuffer buffer = new StringBuffer();
                    buffer.append("name");
                    OutputStreamWriter out = new OutputStreamWriter(http.getOutputStream(), "UTF-8");
                    out.write(buffer.toString());
                    out.flush();

                    InputStreamReader tmp = new InputStreamReader(http.getInputStream(), "UTF-8");
                    BufferedReader reader = new BufferedReader(tmp);
                    StringBuilder builder = new StringBuilder();
                    String str;
                    while ((str = reader.readLine()) != null) {
                        builder.append(str);
                    }
                    String ResultData = builder.toString();
                    final String[] Result = ResultData.split("/");
                    handler2.post(new Runnable() {
                        @Override
                        public void run() {
                            if(estr2==true) {
                                Random random = new Random();
                                int num = random.nextInt(2);
                                if(num==0) {
                                    btn1.setText(Result[0]);
                                    estr1 = false;
                                }
                                else if(num==1) {
                                    btn3.setText(Result[0]);
                                    estr3 = false;
                                }
                                else if(num==2) {
                                    btn4.setText(Result[0]);
                                    estr4 = false;
                                }
                            }
                            else {
                                btn2.setText(Result[0]);
                            }
                        }
                    });

                } catch (Exception e) {
                    Log.e("dataselect()", "지정에러발생", e);
                }
            }
        }.start();
    }
    public void btnselect3() {
        new Thread() {
            @Override
            public void run() {
                try {
                    URL seturl = new URL("Http://10.0.2.2/btnselect1.php/");
                    HttpURLConnection http;
                    http = (HttpURLConnection) seturl.openConnection();
                    http.setDefaultUseCaches(false);
                    http.setDoInput(true);
                    http.setRequestMethod("POST");
                    http.setRequestProperty("content-type", "application/x-www-form-urlencoded");
                    StringBuffer buffer = new StringBuffer();
                    buffer.append("name");
                    OutputStreamWriter out = new OutputStreamWriter(http.getOutputStream(), "UTF-8");
                    out.write(buffer.toString());
                    out.flush();

                    InputStreamReader tmp = new InputStreamReader(http.getInputStream(), "UTF-8");
                    BufferedReader reader = new BufferedReader(tmp);
                    StringBuilder builder = new StringBuilder();
                    String str;
                    while ((str = reader.readLine()) != null) {
                        builder.append(str);
                    }
                    String ResultData = builder.toString();
                    final String[] Result = ResultData.split("/");
                    handler2.post(new Runnable() {
                        @Override
                        public void run() {
                            if(estr3==true) {
                                Random random = new Random();
                                int num = random.nextInt(2);
                                if(num==0) {
                                    btn1.setText(Result[0]);
                                    estr1 = false;
                                }
                                else if(num==1) {
                                    btn2.setText(Result[0]);
                                    estr2 = false;
                                }
                                else if(num==2) {
                                    btn4.setText(Result[0]);
                                    estr4 = false;
                                }
                            }
                            else  {
                                btn3.setText(Result[0]);
                            }
                        }
                    });

                } catch (Exception e) {
                    Log.e("dataselect()", "지정에러발생", e);
                }
            }
        }.start();
    }
    public void btnselect4() {
        new Thread() {
            @Override
            public void run() {
                try {
                    URL seturl = new URL("Http://10.0.2.2/btnselect1.php/");
                    HttpURLConnection http;
                    http = (HttpURLConnection) seturl.openConnection();
                    http.setDefaultUseCaches(false);
                    http.setDoInput(true);
                    http.setRequestMethod("POST");
                    http.setRequestProperty("content-type", "application/x-www-form-urlencoded");
                    StringBuffer buffer = new StringBuffer();
                    buffer.append("name");
                    OutputStreamWriter out = new OutputStreamWriter(http.getOutputStream(), "UTF-8");
                    out.write(buffer.toString());
                    out.flush();

                    InputStreamReader tmp = new InputStreamReader(http.getInputStream(), "UTF-8");
                    BufferedReader reader = new BufferedReader(tmp);
                    StringBuilder builder = new StringBuilder();
                    String str;
                    while ((str = reader.readLine()) != null) {
                        builder.append(str);
                    }
                    String ResultData = builder.toString();
                    final String[] Result = ResultData.split("/");
                    handler2.post(new Runnable() {
                        @Override
                        public void run() {
                            if(estr4==true) {
                                Random random = new Random();
                                int num = random.nextInt(2);
                                if(num==0) {
                                    btn1.setText(Result[0]);
                                    estr1 = false;
                                }
                                else if(num==1) {
                                    btn2.setText(Result[0]);
                                    estr2 = false;
                                }
                                else if(num==2) {
                                    btn3.setText(Result[0]);
                                    estr3 = false;
                                }
                            }
                            else  {
                                btn4.setText(Result[0]);
                            }
                        }
                    });

                } catch (Exception e) {
                    Log.e("dataselect()", "지정에러발생", e);
                }
            }
        }.start();
    }
    public void statinsert(String collectd, String incollectd, String dated, String userd) {
        new Thread() {
            @Override
            public void run() {
                try {
                    URL seturl = new URL("Http://10.0.2.2/statinsert.php/");
                    HttpURLConnection http;
                    http = (HttpURLConnection) seturl.openConnection();
                    http.setDefaultUseCaches(false);
                    http.setDoInput(true);
                    http.setRequestMethod("POST");
                    http.setRequestProperty("content-type", "application/x-www-form-urlencoded");
                    StringBuffer buffer = new StringBuffer();
                    buffer.append("name").append("=").append(collectd).append("/").append(incollectd).append("/").append(dated).append("/").append(userd);
                    OutputStreamWriter out = new OutputStreamWriter(http.getOutputStream(), "UTF-8");
                    out.write(buffer.toString());
                    out.flush();
                    InputStreamReader tmp = new InputStreamReader(http.getInputStream(), "UTF-8");
                    final BufferedReader reader = new BufferedReader(tmp);
                    while (reader.readLine() != null) {
                        System.out.println(reader.readLine());
                    }
                } catch (Exception e) {
                    Log.e("dataInsert()", "지정에러발생", e);
                }
            }
        }.start();
    }
}